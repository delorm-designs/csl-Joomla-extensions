<?php
// Protect from unauthorized access
defined('_JEXEC') or die('Restricted Access');

define('ADMINTOOLS_VERSION', '2.2.9');
define('ADMINTOOLS_DATE', '2012-06-22');
define('ADMINTOOLS_PRO','0');