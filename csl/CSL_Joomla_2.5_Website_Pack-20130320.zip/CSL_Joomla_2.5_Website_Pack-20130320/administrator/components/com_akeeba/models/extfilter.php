<?php
/**
 * @package AkeebaBackup
 * @copyright Copyright (c)2009-2012 Nicholas K. Dionysopoulos
 * @license GNU General Public License version 3, or later
 *
 * @since 2.1
 */

require_once JPATH_COMPONENT_ADMINISTRATOR.'/plugins/models/extfilter.php';