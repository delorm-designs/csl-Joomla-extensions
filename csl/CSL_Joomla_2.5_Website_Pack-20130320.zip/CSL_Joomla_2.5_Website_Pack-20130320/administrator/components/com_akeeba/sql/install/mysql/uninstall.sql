DROP TABLE IF EXISTS `#__ak_profiles`;
DROP TABLE IF EXISTS `#__ak_stats`;
DROP TABLE IF EXISTS `#__ak_storage`;