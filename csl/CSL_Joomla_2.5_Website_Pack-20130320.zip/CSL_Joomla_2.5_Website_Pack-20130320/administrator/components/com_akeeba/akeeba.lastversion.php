<?php
defined('_JEXEC') or die();
define('AKEEBA_LASTVERSIONCHECK','3.5.2');