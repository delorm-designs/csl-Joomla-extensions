DROP TABLE IF EXISTS `#__uniterevolution_sliders`;
DROP TABLE IF EXISTS `#__uniterevolution_slides`;