<?php
/**
 * @package		JCalPro
 * @subpackage	com_jcalpro

**********************************************
JCal Pro
Copyright (c) 2006-2012 Anything-Digital.com
Copyright (c) 2016 Open Source Training, LLC
**********************************************
JCalPro is a native Joomla! calendar component for Joomla!

JCal Pro was once a fork of the existing Extcalendar component for Joomla!
(com_extcal_0_9_2_RC4.zip from mamboguru.com).
Extcal (http://sourceforge.net/projects/extcal) was renamed
and adapted to become a Mambo/Joomla! component by
Matthew Friedman, and further modified by David McKinnis
(mamboguru.com) to repair some security holes.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This header must not be removed. Additional contributions/changes
may be added to this header as long as no information is deleted.
**********************************************
Get the latest version of JCal Pro at:
https://joomlashack.com
**********************************************

 */

defined('JPATH_PLATFORM') or die;

JLoader::register('JCalProBaseControllerForm', JCalProHelperPath::library() . '/controllers/basecontrollerform.php');

class JCalProControllerRegistration extends JCalProBaseControllerForm
{
    public function __construct($config = array())
    {
        // we're not doing a great check here - just a quickie to see if there are any events at all!
        $db = JFactory::getDbo();
        $db->setQuery(((string) $db->getQuery(true)
            ->select('id')
            ->from('#__jcalpro_events')
            ->where('published = 1')
            ) . ' LIMIT 1'
        );
        $events = $db->loadResult();
        if (0 == (int) $events) {
            JFactory::getApplication()->redirect(JRoute::_('index.php?option=com_jcalpro&view=events', false), JText::_('COM_JCALPRO_CANNOT_CREATE_REGISTRATIONS_WITHOUT_EVENTS'), 'error');
            jexit();
        }
        parent::__construct($config);
    }

    /**
     * method to add a new registration
     *
     */
    public function add()
    {
        $add = parent::add();
        $this->_saveRegistrationFormData();
        return $add;
    }

    /**
     * method to edit an existing registration
     *
     */
    public function edit()
    {
        $edit = parent::edit();
        $this->_saveRegistrationFormData();
        return $edit;
    }

    /**
     * override these methods so we can also add the Itemid
     *
     */
    protected function getRedirectToItemAppend($recordId = null, $urlVar = 'id')
    {
        // get the results of the parent method
        $append = parent::getRedirectToItemAppend($recordId, $urlVar);
        // add event_id
        $event = JFactory::getApplication()->input->get('event_id', 0, 'uint');
        if (!empty($event)) {
            $append .= '&event_id=' . $event;
        }
        // return final append string
        return $append;
    }

    /**
     * we use this to save form data
     *
     */
    private function _saveRegistrationFormData()
    {
        $app     = JFactory::getApplication();
        $context = "$this->option.edit.$this->context";
        $data    = $app->input->post->get('jform', array(), 'array');
        $app->setUserState($context . '.data', $data);
    }
}
