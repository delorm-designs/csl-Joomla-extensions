<?php
/**
 * @package		JCalPro
 * @subpackage	com_jcalpro

**********************************************
JCal Pro
Copyright (c) 2006-2012 Anything-Digital.com
Copyright (c) 2016 Open Source Training, LLC
**********************************************
JCalPro is a native Joomla! calendar component for Joomla!

JCal Pro was once a fork of the existing Extcalendar component for Joomla!
(com_extcal_0_9_2_RC4.zip from mamboguru.com).
Extcal (http://sourceforge.net/projects/extcal) was renamed
and adapted to become a Mambo/Joomla! component by
Matthew Friedman, and further modified by David McKinnis
(mamboguru.com) to repair some security holes.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This header must not be removed. Additional contributions/changes
may be added to this header as long as no information is deleted.
**********************************************
Get the latest version of JCal Pro at:
https://joomlashack.com
**********************************************

 */

defined('JPATH_PLATFORM') or die;

// register the other helpers

abstract class JCalProHelperTheme
{
    protected static $themes = null;

    /**
     * static method to get the current theme
     *
     * @return string
     */
    public static function current()
    {
        static $theme;
        if (!isset($theme)) {
            jimport('joomla.filesystem.folder');
            $app    = JFactory::getApplication();
            $theme  = basename($app->getUserStateFromRequest(JCalPro::COM . '.theme', 'theme', JCalPro::config('default_theme', ''), 'string'));
            // check if the theme is actually available
            if (!JFolder::exists(JCalProHelperPath::theme() . '/' . $theme)) {
                $theme = '';
                $app->setUserState(JCalPro::COM . '.theme', '');
            }
        }
        return $theme;
    }

    /**
     * static method to add a stylesheet to the document
     *
     * @param string $file
     * @param string $base
     * @param string $template
     */
    public static function addStyleSheet($file, $base = 'css', $template = '')
    {
        // get our document
        $doc = JFactory::getDocument();
        // if the document cannot have styles added, bail
        if (!method_exists($doc, 'addStyleSheet')) {
            return;
        }
        // sanitise the filename a little
        $css = self::getFilePath("$file.css", $base, $template);
        if ($css) {
            $doc->addStyleSheet($css);
        }
    }

    public static function addIEStyleSheet($file, $version = 0, $diff = '')
    {
        $document = JFactory::getDocument();
        if (!method_exists($document, 'addCustomTag')) {
            return;
        }
        $version                                                     = (int) $version;
        if (!in_array($diff, array('gt', 'gte', 'lt', 'lte'))) {
            $diff = '';
        }
        $tag                                                         = array('');
        $tag[]                                                       = '<!--[if ' . (empty($diff) ? '' : "$diff ") . 'IE' . ($version ? " $version" : '') . ']>';
        $tag[]                                                       = '<link href="' . JCalProHelperFilter::escape($file) . '" rel="stylesheet" type="text/css" />';
        $tag[]                                                       = '<![endif]-->';
        $tag[]                                                       = '';
        $document->addCustomTag(implode("\n", $tag));
    }

    /**
     * removes a stylesheet from the doc, if possible
     *
     * @param unknown_type $file
     */
    public static function removeStyleSheet($file)
    {
        return self::_removeAsset($file, 'stylesheet');
    }

    public static function removeScript($file)
    {
        return self::_removeAsset($file, 'script');
    }

    private static function _removeAsset($file, $type)
    {
        switch (strtolower($type)) {
            case 'script':
                $prop = '_scripts';
                break;
            case 'stylesheet':
                $prop = '_styleSheets';
                break;
            default: return false;
        }
        $document = JFactory::getDocument();
        if (property_exists($document, $prop) && is_array($document->$prop) && array_key_exists($file, $document->$prop)) {
            unset($document->$prop[$file]);
            JCalPro::debugger('Remove Asset ' . $file, $document->$prop);
        }
        return true;
    }

    /**
     * static method to get the url of a file
     *
     * @param string $file
     * @param string $base
     * @param string $template
     */
    public static function getFilePath($file, $base, $template = '')
    {
        jimport('joomla.filesystem.file');
        // sanitise the filename a little
        $file = basename($file);
        $base = trim($base, '/');
        // now load the css file for the theme, if available
        $theme = basename(empty($template) ? self::current() : $template);
        if (!empty($theme) && JFile::exists(JCalProHelperPath::media() . "/themes/$theme/$base/$file")) {
            return JCalProHelperUrl::media() . "/themes/$theme/$base/$file";
        }
        // no theme? load the default css, if it exists
        elseif (JFile::exists(JCalProHelperPath::media() . "/$base/$file")) {
            return JCalProHelperUrl::media() . "/$base/$file";
        }
        return false;
    }

    /**
     * static method to get a list of available themes
     *
     * @return array
     */
    public static function getList()
    {
        if (static::$themes === null) {
            jimport('joomla.filesystem.folder');

            $db = JFactory::getDbo();
            $query = $db->getQuery(true)
                ->select('element, name')
                ->from('#__extensions')
                ->where('LOWER(' . $db->quoteName('name') . ') LIKE "files_jcaltheme_%"')
                ->where('enabled = 1')
                ->order($db->quoteName('name'));

            $db->setQuery((string) $query);
            $dbthemes = $db->loadObjectList();


            $fsthemes = JFolder::folders(JCalProHelperPath::theme());

            static::$themes = array(JHtml::_('select.option', '', JText::_('COM_JCALPRO_THEMES_DEFAULT')));
            foreach ($dbthemes as $theme) {
                $themename = preg_replace('/^(files_)?jcaltheme_/i', '', strtolower($theme->element));

                if (!in_array($themename, $fsthemes)) {
                    // Not in the filesystem
                    continue;
                }

                JCalPro::language(strtolower($theme->name . '.sys'), JPATH_ROOT);
                static::$themes[] = JHtml::_('select.option', $themename, JText::_($theme->name . '_NAME'));
            }
        }

        return static::$themes;
    }

    public static function getConfig($key = null)
    {
        static $config;
        static $defaults;
        $current = 'jcaltheme_' . JCalProHelperTheme::current();
        if (!is_array($defaults)) {
            $defaults = array(
                'load_common' => 1
            );
        }
        if (!is_array($config)) {
            $db = JFactory::getDbo();
            $db->setQuery($db->getQuery(true)
                ->select($db->quoteName('extension_id'))
                ->select($db->quoteName('element'))
                ->select($db->quoteName('params'))
                ->from('#__extensions')
                ->where($db->quoteName('element') . ' LIKE "jcaltheme_%"')
            );
            try {
                $config = $db->loadObjectList('element');
                if (!empty($config)) {
                    foreach ($config as $theme => &$data) {
                        $data->params = json_decode($data->params);
                        /*
                        foreach ($defaults as $defkey => $defvalue) {
                            if (!is_object($data->params)) {
                                $data->params = new stdClass;
                            }
                            if (!property_exists($data->params, $defkey)) {
                                $data->params->{$defkey} = $defvalue;
                            }
                        }
                        */
                    }
                }
                // force this to be an array
                else {
                    $config = array();
                }
            } catch (Exception $e) {
                JCalProHelperLog::error($e->getMessage());
                $config = array();
            }

            // if we have no config from database, see if the current theme has defaults
            // this should help get around a known installer bug (that we haven't fixed yet and probably won't)
            if (empty($config)) {
                // get the current theme's manifest, if any
                jimport('joomla.filesystem.file');
                $xmlFile = JPATH_ADMINISTRATOR . '/manifests/files/' . $current . '.xml';
                if (JFile::exists($xmlFile)) {
                    // piggyback code from core
                    jimport('joomla.installer.installer') or jimport('cms.installer.installer');
                    $installer = new JInstaller;
                    // get our manifest as an internal joomla object
                    $manifest = $installer->isManifest($xmlFile);
                    if (!is_null($manifest)) {
                        $installer->manifest = $manifest;
                        $installer->setPath('manifest', $xmlFile);
                        $config = $installer->getParams();
                    }
                }
            }

            JCalPro::debugger('Theme Configuration', $config);
        }
        if (is_array($config) && array_key_exists($current, $config) && is_object($config[$current]) && property_exists($config[$current], 'params') && is_object($config[$current]->params) && property_exists($config[$current]->params, $key)) {
            return $config[$current]->params->{$key};
        }
        if (array_key_exists($key, $defaults)) {
            return $defaults[$key];
        }
        return null;
    }

    public static function isTooWhite($color)
    {
        $color = (string) $color;
        // force to lower case to process
        $color = JString::strtolower($color);
        // check for color codes like "white" or "blue"
        // TODO
        switch ($color) {
            case 'yellow':
            case 'white':
                return true;
            case 'black':
            case 'blue':
            case 'green':
            case 'red':
                return false;
            default:
                $rgb = JCalProHelperTheme::hexToRGB($color);
        }
        if (!is_array($rgb)) {
            return false;
        }
        return 130 < (($rgb['r'] * .299) + ($rgb['g'] * .587) + ($rgb['b'] * .114));
    }

    /**
     * Converts a 3 or 6 character hex color to an rgb array
     *
     * @param string $color
     *
     * @return array parsed rgb array
     * @return bool  false if color could not be parsed
     */
    public static function hexToRGB($color)
    {
        $color = (string) $color;
        // remove css hash from color, if applicable
        if (false !== strpos($color, '#')) {
            $color = trim($color, '#');
        }
        // force to lower case to process
        $color = JString::strtolower($color);
        if (preg_match('/[^0-9a-f]/', $color)) {
            return false;
        }
        // check for hex codes - either in RRGGBB or RGB
        if (6 === JString::strlen($color)) {
            $r = hexdec(JString::substr($color, 0, 2));
            $g = hexdec(JString::substr($color, 2, 2));
            $b = hexdec(JString::substr($color, 4, 2));
        } elseif (3 === JString::strlen($color)) {
            $r = hexdec(str_repeat(JString::substr($color, 0, 1), 2));
            $g = hexdec(str_repeat(JString::substr($color, 1, 1), 2));
            $b = hexdec(str_repeat(JString::substr($color, 2, 1), 2));
        }
        // not a hex code based on length - no clue
        else {
            return false;
        }
        return array('r' => $r, 'g' => $g, 'b' => $b);
    }
}
