<?php
/**
 * @package         Regular Labs Installer
 * @version         16.10.4775
 * 
 * @author          Peter van Westen <info@regularlabs.com>
 * @link            http://www.regularlabs.com
 * @copyright       Copyright © 2016 Regular Labs All Rights Reserved
 * @license         http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

defined('_JEXEC') or die;

if (!class_exists('RegularLabsInstaller'))
{
	require_once __DIR__ . '/script.helper.php';
}

class PlgSystemRegularLabsInstallerArticlesanywhereInstallerScript extends RegularLabsInstaller
{
	var $dir           = null;
	var $installerName = 'regularlabsinstallerarticlesanywhere';

	public function __construct()
	{
		$this->dir = __DIR__;
	}
}
