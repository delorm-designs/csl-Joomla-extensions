<?php
/**
* @package RSform!Pro
* @copyright (C) 2014 www.rsjoomla.com
* @license GPL, http://www.gnu.org/copyleft/gpl.html
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.plugin.helper');

class bfFormsImport
{
	protected static $message = array();
	
	public static function isInstalled()
	{
		return file_exists(JPATH_ADMINISTRATOR.'/components/com_form/0_form.xml');
	}
	
	public static function getForms()
	{
		$db 	= JFactory::getDbo();
		$query 	= $db->getQuery(true);
		$query->select($db->qn('id'))
			  ->select($db->qn('form_name'))
			  ->from($db->qn('#__form_forms'));
		return $db->setQuery($query)
				  ->loadObjectList();
	}
	
	public static function hasAkismet()
	{		
		$db 	= JFactory::getDbo();
		$query 	= $db->getQuery(true);
		$query->select($db->qn('id'))
			  ->from($db->qn('#__form_forms'))
			  ->where($db->qn('spam_akismet_key') . ' != ' . $db->q(''));
		
		return $db->setQuery($query)->loadResult() && !JPluginHelper::isEnabled('system', 'rsfpakismet');
	}
	
	public static function hasMailChimp()
	{		
		$db 	= JFactory::getDbo();
		$query 	= $db->getQuery(true);
		$query->select($db->qn('id'))
			  ->from($db->qn('#__form_actions'))
			  ->where($db->qn('plugin') . ' = ' . $db->q('mailchimp'));
		
		return $db->setQuery($query)->loadResult() && !JPluginHelper::isEnabled('system', 'rsfpmailchimp');
	}
	
	public static function hasSalesforce()
	{		
		$db 	= JFactory::getDbo();
		$query 	= $db->getQuery(true);
		$query->select($db->qn('id'))
			  ->from($db->qn('#__form_actions'))
			  ->where($db->qn('plugin') . ' = ' . $db->q('salesforcew2l'));
		
		return $db->setQuery($query)->loadResult() && !JPluginHelper::isEnabled('system', 'rsfpsalesforce');
	}
	
	protected static function _getFormId()
	{
		return JFactory::getApplication()->input->getInt('id');
	}
	
	protected static function _getReplaceCaptcha()
	{
		return JFactory::getApplication()->input->getInt('bfcaptcha');
	}
	
	protected static function _getMoveFiles()
	{
		return JFactory::getApplication()->input->getInt('bfmovefiles');
	}
	
	protected static function _getMoveSubmissions()
	{
		return JFactory::getApplication()->input->getInt('bfsubmissions');
	}
	
	protected static function _getLimit()
	{
		return JFactory::getApplication()->input->getInt('limit', 30);
	}
	
	protected static function _getLimitStart()
	{
		return JFactory::getApplication()->input->getInt('limitstart');
	}
	
	protected static function _getRSFormId()
	{
		return JFactory::getApplication()->input->getInt('formId');
	}
	
	public static function importForms()
	{
		$db 			  = JFactory::getDbo();
		$id 			  = self::_getFormId();
		$replace_captcha  = self::_getReplaceCaptcha();
		$move_files 	  = self::_getMoveFiles();
		$move_submissions = self::_getMoveSubmissions();
		$limitstart		  = self::_getLimitStart();
		$limit			  = self::_getLimit();
		$formId			  = self::_getRSFormId();
		
		$query = $db->getQuery(true)
					->select('*')
					->from($db->qn('#__form_forms'))
					->where($db->qn('id') . ' = ' . $db->q($id));
		
		$bfform = $db->setQuery($query)->loadObject();
		
		if ($limitstart == 0)
		{
			$form->ScriptDisplay = '';
			
			$scripts['display']  	= array();
			$scripts['process']  	= array();
			$scripts['process2'] 	= array();
			$scripts['useremail']  	= array();
			$scripts['adminemail'] 	= array();
			$scripts['addemail'] 	= array();
			
			$form = JTable::getInstance('RSForm_Forms', 'Table');
			$form->Published = $bfform->published;
			$form->FormName  = $bfform->form_name;
			$form->FormTitle = $bfform->page_title;
			$form->MetaTitle = $bfform->showtitle;
			
			// these are added as actions in bfForms
			$form->Keepdata  	 = 0;
			$form->ShowThankyou  = 0;
			$form->store();
			
			if ($bfform->access) {
				$form->Access = 2;
			}
			
			if (!is_string($form->CSSAdditionalAttributes)) {
				$form->CSSAdditionalAttributes = '';
			}
			
			if ($bfform->target) {
				$form->CSSAdditionalAttributes .= ' target="'.$bfform->target.'"';
			}
			
			if ($bfform->{'accept-charset'}) {
				$form->CSSAdditionalAttributes .= ' accept-charset="'.$bfform->{'accept-charset'}.'"';
			}
			
			if ($bfform->processorurl) {
				$form->CSSAction = $bfform->processorurl;
			}
			
			if ($bfform->custom_js) {
				$form->JS = '<script type="text/javascript">'.
							"\n".$bfform->custom_js.
							"\n".'</script>';
			}
							
			if ($bfform->custom_css) {
				$form->CSS = '<style type="text/css">'.
							 "\n".$bfform->custom_css.
							 "\n".'</style>';
			}
			
			if ($bfform->maxsubmissions) {
				array_push($scripts['display'],
					'// Migrated from bfForms - Maximum number of sucessful submissions this form will accept',
					'$db 	= JFactory::getDbo();',
					'$query = $db->getQuery(true)',
					'->select("COUNT(".$db->qn("SubmissionId").")")',
					'->from($db->qn("__rsform_submissions"))',
					'->where($db->qn("FormId") . " = " . $db->q($formId));',
					'if ($db->setQuery($query)->loadResult() > '.(int) $bfform->maxsubmissions.') {',
					'	JFactory::getApplication()->enqueueMessage("Unfortunately, this form has reached its submissions limit.");',
					'	$formLayout = "";',
					'}',
					''
				);
			}
			
			if ($bfform->maxsubmissionsperuser) {
				array_push($scripts['display'],
					'// Migrated from bfForms - Number of times a visitor/user can submit this form successfully',
					'$db 	= JFactory::getDbo();',
					'$user 	= JFactory::getUser()->id;',
					'$query = $db->getQuery(true)',
					'->select("COUNT(".$db->qn("SubmissionId").")")',
					'->from($db->qn("__rsform_submissions"))',
					'->where($db->qn("FormId") . " = " . $db->q($formId));',
					'if ($user) {',
					'	$query->where($db->qn("UserId") . " = " . $db->q($user));',
					'} else { ',
						'$query->where($db->qn("UserIp") . " = " . $db->q($_SERVER["REMOTE_ADDR"]));',
					'}',
					'if ($db->setQuery($query)->loadResult() > '.(int) $bfform->maxsubmissionsperuser.') {',
					'	JFactory::getApplication()->enqueueMessage("Unfortunately, you have reached the number of submissions available for this form.");',
					'	$formLayout = "";',
					'}',
					''
				);
			}
			
			if ($bfform->spam_ipblacklist) {
				$bfform->spam_ipblacklist = explode("\n", str_replace(array("\r\n", "\r"), "\n", $bfform->spam_ipblacklist));
				array_walk($bfform->spam_ipblacklist, array('self', '_addSlashes'));
				
				array_push($scripts['display'],
					'// Migrated from bfForms - Manual IP Blacklist',
					'$banned_ips = array(\''.implode("','", $bfform->spam_ipblacklist).'\');',
					'if (in_array($_SERVER[\'REMOTE_ADDR\'], $banned_ips)) {',
					'	JFactory::getApplication()->enqueueMessage(\'Unfortunately, you cannot submit this form.\');',
					'	$formLayout = \'\';',
					'}',
					''
				);
				
				array_push($scripts['process'],
					'// Migrated from bfForms - Manual IP Blacklist',
					'$banned_ips = array(\''.implode("','", $bfform->spam_ipblacklist).'\');',
					'if (in_array($_SERVER[\'REMOTE_ADDR\'], $banned_ips)) {',
					'	JFactory::getApplication()->enqueueMessage(\'Unfortunately, you cannot submit this form.\');',
					'	$formLayout = \'\';',
					'}',
					''
				);
			}
			
			if ($bfform->spam_wordblacklist) {
				$bfform->spam_wordblacklist = explode('|', $bfform->spam_wordblacklist);
				array_walk($bfform->spam_wordblacklist, array('self', '_addSlashes'));
				
				array_push($scripts['process'],
					'// Migrated from bfForms - Reject Submissions Which Contain These Words',
					'$banned_words = array(\''.implode("','", $bfform->spam_wordblacklist).'\');',
					'foreach ($banned_words as $word) {',
					'	foreach ($_POST[\'form\'] as $key => $val) {',
					'		if (is_array($val)) {',
					'			$val = implode(\',\', $val);',
					'		}',
					'		if (strstr(strtolower($val), strtolower($word))) {',
					'			JFactory::getApplication()->enqueueMessage(\'Your submission contains banned words.\');',
					'			$invalid[] = RSFormProHelper::getComponentId($key);',
					'			break 2;',
					'		}',
					'	}',
					'}'
				);
			}
			
			$query = $db->getQuery(true)
						->select('*')
						->from($db->qn('#__form_fields'))
						->where($db->qn('form_id') . ' = ' . $db->q($bfform->id));
			
			$bffields = $db->setQuery($query)->loadObjectList();
			$upload_fields = array();
			foreach ($bffields as $bffield) {
				$component   = self::_convertField($bffield, $scripts);
				$componentId = self::_addComponent($component, $form->FormId);
				
				// upload field
				if ($component->ComponentTypeId == 9) {
					$upload_fields[] = $componentId;
				}
			}
			
			$newOrder = isset($component->Order) ? $component->Order+1 : 1;
			
			if ($bfform->spam_hiddenfield)
			{
				if ($replace_captcha)
				{
					$component = new stdClass();
					$component->Order = $newOrder;
					$component->ComponentTypeId = 8;
					$component->Published = 1;
					$component->properties['NAME'] = $bfform->spam_hiddenfield;
					$component->properties['CAPTION'] = 'SPAM Protection';
					$component->properties['LENGTH'] = 4;
					$component->properties['BACKGROUNDCOLOR'] = '#FFFFFF';
					$component->properties['TEXTCOLOR'] = '#000000';
					$component->properties['TYPE'] = 'ALPHANUMERIC';
					$component->properties['ADDITIONALATTRIBUTES'] = 'style="text-align:center;width:75px;"';
					$component->properties['DESCRIPTION'] = '';
					$component->properties['COMPONENTTYPE'] = 8;
					$component->properties['VALIDATIONMESSAGE'] = 'Please type the 4 character code you see in the image above.';
					$component->properties['FLOW'] = 'HORIZONTAL';
					$component->properties['SHOWREFRESH'] = 'YES';
					$component->properties['REFRESHTEXT'] = JText::_('RSFP_COMP_FVALUE_REFRESH');
					$component->properties['SIZE'] = '15';
					$component->properties['IMAGETYPE'] = 'FREETYPE';
					
					$componentId = self::_addComponent($component, $form->FormId);
				}
				else
				{
					$component = new stdClass();
					$component->Order = $newOrder;
					$component->ComponentTypeId = 1;
					$component->Published = 1;
					$component->properties['NAME'] = $bfform->spam_hiddenfield;
					$component->properties['CAPTION'] = '';
					$component->properties['REQUIRED'] = 'NO';
					$component->properties['SIZE'] = 20;
					$component->properties['MAXSIZE'] = '';
					$component->properties['VALIDATIONRULE'] = 'none';
					$component->properties['VALIDATIONMESSAGE'] = '';
					$component->properties['ADDITIONALATTRIBUTES'] = 'style="display: none;"';
					$component->properties['DEFAULTVALUE'] = '';
					$component->properties['DESCRIPTION'] = '';
					$component->properties['COMPONENTTYPE'] = 1;
					$component->properties['VALIDATIONEXTRA'] = '';
					
					$componentId = self::_addComponent($component, $form->FormId);
					
					array_push($scripts['process'],
						'// Migrated from bfForms - SPAM hidden field protection',
						'if (!empty($_POST[\'form\'][\''.addslashes($bfform->spam_hiddenfield).'\'])) {',
						'	$invalid[] = \''.$componentId.'\';',
						'}',
						''
					);
				}
				
				$newOrder++;
			}
			
			if (!$bfform->usecustomtemplate) {
				jimport('joomla.application.component.model');
				
				$form->FormLayoutAutogenerate = 1;
				$form->FormLayoutName = 'inline-xhtml';
				$form->store();
				
				$component = new stdClass();
				$component->Order = $newOrder;
				$component->ComponentTypeId = 13;
				$component->Published = 1;
				$component->properties['NAME'] = 'submit';
				$component->properties['CAPTION'] = '';
				$component->properties['LABEL'] = $bfform->submitbuttontext;
				$component->properties['RESET'] = $bfform->showresetbutton ? 'YES' : 'NO';
				$component->properties['RESETLABEL'] = $bfform->resetbuttontext;
				$component->properties['ADDITIONALATTRIBUTES'] = '';
				$component->properties['COMPONENTTYPE'] = 13;
				$component->properties['PREVBUTTON'] = JText::_('PREV');
				
				$componentId = self::_addComponent($component, $form->FormId);
				
				// create layout xhtml
				JRequest::setVar('formId', $form->FormId);
				
				$model = JModel::getInstance('Forms', 'RSFormModel', array('base_path' => JPATH_ADMINISTRATOR.'/components/com_rsform'));
				$model->getForm();
				
				$model->autoGenerateLayout();
				$form->FormLayout = $model->_form->FormLayout;
				$form->store();
			} else {
				$form->FormLayoutAutogenerate = 0;
				
				// parse smarty template
				$replace = array('{$FORM_OPEN_TAG}', '{$FORM_CLOSE_TAG}');
				$with  	 = array('', '');
				
				$slugs = self::_getSlugs($id);
				foreach ($slugs as $slug) {
					array_push($replace, '{$'.strtoupper($slug).'_TITLE}', '{$'.strtoupper($slug).'_DESC}', '{$'.strtoupper($slug).'_ELEMENT}');
					array_push($with, '{'.$slug.':caption}', '{'.$slug.':description}', '{'.$slug.':body}<br />'.'{'.$slug.':validation}<br />');
				}
				
				$form->FormLayout = str_replace($replace, $with, $bfform->custom_smarty);
			}
			
			$query = $db->getQuery(true)
						->select('*')
						->from($db->qn('#__form_actions'))
						->where($db->qn('form_id') . ' = ' . $db->q($id))
						->where($db->qn('published') . ' = ' . $db->q(1))
						->order($db->qn('ordering'). ' ' . $db->escape('asc'));
			
			$bfactions = $db->setQuery($query)->loadObjectList();
			foreach ($bfactions as $bfaction) {
				self::_convertAction($bfaction, $scripts, $form, $upload_fields, $id);
			}
			
			if ($bfform->spam_akismet_key && JPluginHelper::isEnabled('system', 'rsfpakismet'))
			{
				$row 				 = JTable::getInstance('RSForm_Akismet', 'Table');
				$row->form_id 		 = $form->FormId;
				$row->aki_published  = 1;
				$row->aki_merge_vars = serialize(array(
					'author' => $bfform->spam_akismet_author,
					'email'	 => $bfform->spam_akismet_email,
					'body' 	 => $bfform->spam_akismet_body
				));
				$row->store();
				
				$config = RSFormProConfig::getInstance();
				$config->set('aki.key', $bfform->spam_akismet_key);
			}
			
			/*
			$bfform->nextbuttontext;
			$bfform->prevbuttontext;
			
			$bfform->spam_mollom_privatekey;
			$bfform->spam_mollom_publickey;
			
			$bfform->enableixedit;
			$bfform->enablejankomultipage;
			*/
			$form->ScriptDisplay  			= implode("\n", $scripts['display']);
			$form->ScriptProcess  			= implode("\n", $scripts['process']);
			$form->ScriptProcess2 			= implode("\n", $scripts['process2']);
			$form->UserEmailScript 			= implode("\n", $scripts['useremail']);
			$form->AdminEmailScript 		= implode("\n", $scripts['adminemail']);
			$form->AdditionalEmailsScript 	= implode("\n", $scripts['addemail']);
			
			$form->store();
			
			$formId = $form->FormId;
		}
		
		// convert submissions
		// ?
		if ($bfform->hasusertable)
		{
			$query = $db->getQuery(true)
						->select('*')
						->from($db->qn($bfform->hasusertable))
						->order($db->qn('id') . ' ' . $db->escape('asc'));
			$submissions = $db->setQuery($query, $limitstart, $limit)->loadObjectList();
			
			if (!$submissions || !$move_submissions) {
				self::_setMessage('action', 'stop');
				self::_setMessage('formId', $formId);
				self::_setMessage('limitstart', ($limitstart+$limit));
				self::_exit();
			}
			
			foreach ($submissions as $submission)
			{
				$db->setQuery("INSERT INTO #__rsform_submissions SET `FormId`='".$formId."', `DateSubmitted`=NOW(), `UserIp`='127.0.0.1', `Username`='', `UserId`='".(int) $submission->bf_user_id."', `Lang`='en-GB', `confirmed`='1'");
				$db->execute();
				$submissionId = $db->insertid();
				
				$values = get_object_vars($submission);
				unset($values['id'], $values['bf_status'], $values['bf_user_id']);
				
				$fields  = self::_getSubmissionFields($values, $id);
				$uploads = self::_getUploadFields($values, $id);
				
				foreach ($values as $key => $val)
				{
					if (!isset($fields[$key]))
						continue;
						
					if (isset($uploads[$key]))
					{						
						switch ($uploads[$key]['setting'])
						{
							// abs path
							case 1:
								$val = $val;
							break;
							
							// url
							default:
							case 2:
								$val = end(explode('/', $val));
								$val = $uploads[$key]['destination'].'/'.$val;
							break;
							
							// filename
							case 3:
								$val = $uploads[$key]['destination'].'/'.$val;
							break;
						}
						
						if (!file_exists($val) || !is_file($val))
							$val = '';
						
						if ($move_files && $val && JFile::copy($val, JPATH_SITE.'/components/com_rsform/uploads/'.basename($val))) {
							$val = JPATH_SITE.'/components/com_rsform/uploads/'.basename($val);
						}
					}
						
					$db->setQuery("INSERT INTO #__rsform_submission_values SET `FormId`='".$formId."', `SubmissionId`='".$submissionId."', `FieldName`='".$db->escape($fields[$key])."', `FieldValue`='".$db->escape($val)."'");
					$db->execute();
				}
			}
			
			self::_setMessage('action', 'repeat');
			self::_setMessage('formId', $formId);
			self::_setMessage('limitstart', ($limitstart+$limit));
			self::_exit();
		}
	}
	
	protected static function _exit()
	{
		ob_end_clean();
		
		header('Content-type: text/xml');
		
		echo "<?xml version='1.0' encoding='utf-8'?>";
		echo '<response>';
		foreach (self::$message as $tag => $value) {
			echo '<'.$tag.'>'.$value.'</'.$tag.'>';
		}
		echo '</response>';
		
		JFactory::getApplication()->close();
	}
	
	protected static function _setMessage($tag, $value)
	{
		self::$message[$tag] = $value;
	}
	
	protected static function _getSubmissionFields($values, $id)
	{
		static $cache;
		
		if (is_null($cache)) {
			$cache 	= array();
			$db		= JFactory::getDbo();
			$query	= $db->getQuery(true)
						 ->select($db->qn('id'))
						 ->select($db->qn('slug'))
						 ->from($db->qn('#__form_fields'))
						 ->where($db->qn('form_id') . ' = ' . $db->q($id));
			$fields = $db->setQuery($query)->loadObjectList();
			
			foreach ($fields as $field) {
				$cache['FIELD_'.$field->id] = $field->slug;
			}
		}
		
		return $cache;
	}
	
	protected static function _getUploadFields($values, $id)
	{
		static $cache;
		
		if (is_null($cache)) {
			jimport('joomla.filesystem.file');
			
			$cache 	= array();
			$db		= JFactory::getDbo();
			$query	= $db->getQuery(true)
						 ->select($db->qn('id'))
						 ->select($db->qn('slug'))
						 ->select($db->qn('fileupload_setvalueto'))
						 ->select($db->qn('fileupload_destdir'))
						 ->from($db->qn('#__form_fields'))
						 ->where($db->qn('form_id') . ' = ' . $db->q($id))
						 ->where($db->qn('plugin') . ' = ' . $db->q('fileupload'));
			$fields = $db->setQuery($query)->loadObjectList();
			
			foreach ($fields as $field) {
				$cache['FIELD_'.$field->id] = array(
					'slug' 			=> $field->slug,
					'setting' 		=> $field->fileupload_setvalueto,
					'destination' 	=> $field->fileupload_destdir
				);
			}
		}
		
		return $cache;
	}
	
	protected static function _convertAction($action, &$scripts, &$form, $upload_fields, $id)
	{
		static $mailcount = 0;
		static $mailids = array();
		
		switch ($action->plugin)
		{
			case 'executephp':
				$slugs = self::_getSlugs($id);
				$bftypes = array();
				$rstypes = array();
				foreach ($slugs as $slug)
				{
					$bftypes[] = '$'.strtoupper($slug);
					$rstypes[] = '$_POST[\'form\'][\''.addslashes($slug).'\']';
				}
				
				$scripts['process2'][] = '// Migrated from bfForms - '.$action->title;
				$scripts['process2'][] = str_replace($bftypes, $rstypes, $action->desc);
				$scripts['process2'][] = '// end - '.$action->title;
			break;
			
			case 'httppost':
				$db    = JFactory::getDbo();
				$query = $db->getQuery(true)
							->insert($db->qn('#__rsform_posts'))
							->set($db->qn('form_id') . ' = ' . $db->q($form->FormId))
							->set($db->qn('enabled') . ' = ' . $db->q(1))
							->set($db->qn('method') . ' = ' . $db->q(1))
							->set($db->qn('silent') . ' = ' . $db->q($action->custom9 ? 0 : 1))
							->set($db->qn('url') . ' = ' . $db->q($action->desc));
				$db->setQuery($query)->execute();
			break;
			
			case 'mail':
				$db = JFactory::getDbo();
				$slugs = self::_getSlugs($id);
				$bftypes = array();
				$rstypes = array();
				foreach ($slugs as $slug)
				{
					$bftypes[] = '#'.strtoupper($slug).'#';
					$rstypes[] = '{'.$slug.':value}';
				}
				
				$action->emailto = str_replace(array("\r\n", "\r", "\n"), ',', $action->emailto);
				$action->emailcc = str_replace(array("\r\n", "\r", "\n"), ',', $action->emailcc);
				$action->emailbcc = str_replace(array("\r\n", "\r", "\n"), ',', $action->emailbcc);
				
				if ($mailcount == 0)
				{
					$form->UserEmailSubject = str_replace($bftypes, $rstypes, $action->emailsubject);
					$form->UserEmailFromName = str_replace($bftypes, $rstypes, $action->emailfromname);
					$form->UserEmailFrom = str_replace($bftypes, $rstypes, $action->emailfrom);
					$form->UserEmailReplyTo = str_replace($bftypes, $rstypes, $action->emailfrom);
					$form->UserEmailTo = str_replace($bftypes, $rstypes, $action->emailto);
					$form->UserEmailCC = str_replace($bftypes, $rstypes, $action->emailcc);
					$form->UserEmailBCC = str_replace($bftypes, $rstypes, $action->emailbcc);
					$form->UserEmailText = $action->emailhtml ? str_replace($bftypes, $rstypes, $action->emailhtml) : str_replace($bftypes, $rstypes, $action->emailplain);
					$form->UserEmailMode = $action->emailhtml ? 1 : 0;
					
					$form->UserEmailAttach = 0;
					$form->UserEmailAttachFile = '';
					if ($action->attachments)
					{
						$tmp = explode("\n", str_replace(array("\r\n", "\r"), "\n", $action->attachments));
						if (count($tmp))
						{
							$form->UserEmailAttach = 1;
							$form->UserEmailAttachFile = $tmp[0];
							
							unset($tmp[0]);
							foreach ($tmp as $file)
								$scripts['useremail'][] = "\$userEmail['files'][] = '".addslashes($file)."';";
						}
					}
				}
				elseif ($mailcount == 1)
				{
					$form->AdminEmailSubject = '';
					$form->AdminEmailFromName = '';
					$form->AdminEmailFrom = '';
					$form->AdminEmailReplyTo = '';
					$form->AdminEmailTo = '';
					$form->AdminEmailCC = '';
					$form->AdminEmailBCC = '';
					$form->AdminEmailText = '';
					$form->AdminEmailMode = '';
					
					$form->AdminEmailAttach = 0;
					$form->AdminEmailAttachFile = '';
					if ($action->attachments)
					{
						$tmp = explode("\n", str_replace(array("\r\n", "\r"), "\n", $action->attachments));
						if (count($tmp))
						{
							$form->AdminEmailAttach = 1;
							$form->AdminEmailAttachFile = $tmp[0];
							
							unset($tmp[0]);
							foreach ($tmp as $file)
								$scripts['adminemail'][] = "\$adminEmail['files'][] = '".addslashes($file)."';";
						}
					}
				}
				else
				{
					$email = JTable::getInstance('RSForm_Emails', 'Table');
					$email->formId = $form->FormId;
					$email->from = str_replace($bftypes, $rstypes, $action->emailfrom);
					$email->fromname = str_replace($bftypes, $rstypes, $action->emailfromname);
					$email->replyto = str_replace($bftypes, $rstypes, $action->emailfrom);
					$email->to = str_replace($bftypes, $rstypes, $action->emailto);
					$email->cc = str_replace($bftypes, $rstypes, $action->emailcc);
					$email->bcc = str_replace($bftypes, $rstypes, $action->emailbcc);
					$email->subject = str_replace($bftypes, $rstypes, $action->emailsubject);
					$email->mode = $action->emailhtml ? 1 : 0;
					$email->message = $action->emailhtml ? str_replace($bftypes, $rstypes, $action->emailhtml) : str_replace($bftypes, $rstypes, $action->emailplain);
					
					if ($email->store())
					{
						$mailids[] = $email->id;
						
						if ($action->attachments)
						{
							$tmp = explode("\n", str_replace(array("\r\n", "\r"), "\n", $action->attachments));
							if (count($tmp))
								foreach ($tmp as $file)
									$scripts['addemail'][] = "if (\$email->id == '".$email->id."') \$additionalEmail['files'][] = '".addslashes($file)."';";
						}
					}
				}
				
				if ($action->senduploadedfiles && count($upload_fields))
				{
					$value = '';
					if ($mailcount == 0)
						$value = 'useremail';
					elseif ($mailcount == 1)
						$value = 'useremail,adminemail';
					else
						$value = 'useremail,adminemail,'.implode(',',$mailids);
					
					$db->setQuery("UPDATE #__rsform_properties SET `PropertyValue`='' WHERE ComponentId IN (".implode(',', $upload_fields).") AND `PropertyName`='EMAILATTACH'");
					$db->execute();
				}
				
				$mailcount++;
			break;
			
			case 'redirect':
				$form->ReturnUrl = $action->desc;
				
				$slugs 		= self::_getSlugs($id);
				$rstypes 	= array();
				foreach ($slugs as $slug) {
					$rstypes[] = $slug.'='.'{'.$slug.':value}';
				}
				if ($action->custom4 == 'GET' && $action->custom6) {
					$form->ReturnUrl .= (strpos($form->ReturnUrl, '?') === false ? '?' : '&').implode('&', $rstypes);
				}
				// $action->title  = title
				// $action->access = access level ?
				// $action->desc   = url
				// $action->custom6 = Send submitted details in the post
				// $action->custom4 = Redirect Method POST GET
			break;
			
			case 'listmessenger':
				// Who uses this? :))
			break;
			
			case 'save':
				$form->Keepdata = 1;
			break;
			
			case 'thankyou':
				$slugs = self::_getSlugs($id);
				$bftypes = array();
				$rstypes = array();
				foreach ($slugs as $slug)
				{
					$bftypes[] = '$'.strtoupper($slug);
					$rstypes[] = '{'.$slug.':value}';
				}
				
				$form->ShowThankyou = 1;
				$form->Thankyou 	= str_replace($bftypes, $rstypes, $action->desc);
			break;
			
			case 'mailchimp':
				if (JPluginHelper::isEnabled('system', 'rsfpmailchimp')) {
					$config = RSFormProConfig::getInstance();
					$config->set('mailchimp.key', $action->custom4);
					
					$row = JTable::getInstance('RSForm_MailChimp', 'Table');
					$row->form_id 		= $form->FormId;
					$row->mc_list_id 	= $action->custom5;
					$row->mc_action 	= $action->custom6;
					$row->mc_merge_vars = serialize(array(
						'EMAIL' => $action->emailto,
						'FNAME' => $action->emailfrom,
						'LNAME' => $action->emailfromname,
					));
					$row->mc_published 	= 1;
					$row->store();
				}
			break;
			
			case 'salesforcew2l':
				if (JPluginHelper::isEnabled('system', 'rsfpsalesforce')) {
					$row = JTable::getInstance('RSForm_Salesforce', 'Table');
					$row->form_id 		 = $form->FormId;
					$row->slsf_published = 1;
					
					if (preg_match('#name="oid" value="(.*?)"#is', $action->custom5, $match))
						$row->slsf_oid = $match[1];
					
					if ($action->custom6 == 1)
					{
						$row->slsf_debug = 1;
						if (preg_match('#name="debugEmail" value="(.*?)"#is', $action->custom5, $match))
							$row->slsf_debugEmail = $match[1];
					}
					
					$custom = array();
					$pairs  = explode("\n", $action->custom4);
					foreach ($pairs as $pair)
					{
						$pair = trim($pair);
						list($salesforce, $field) = @explode(':', $pair, 2);
						
						$check = 'slsf_'.$salesforce;
						
						if (isset($row->$check))
							$row->$check = '{'.$field.':value}';
						else
						{
							$tmp = new stdClass();
							$tmp->api_name = $salesforce;
							$tmp->value    = '{'.$field.':value}';
							
							$custom[] = $tmp;
						}
					}
					$row->slsf_custom_fields = serialize($custom);
					
					$row->store();
				}
			break;
		}
	}
	
	protected static function _convertField($field, &$scripts)
	{
		$lang = JFactory::getLanguage();
		$component = new stdClass();
		$component->properties = array();
		$component->properties['NAME'] = $field->slug;
		$component->Published = $field->published;
		$component->Order = $field->ordering;
		
		switch ($field->plugin)
		{
			case 'radio':
			case 'checkbox':
				$component->ComponentTypeId = ($field->plugin == 'radio') ? 5 : 4;
				
				if ($field->multiple)
					$field->value = RSFormProHelper::checkValue($field->multiple, $field->value);
				
				$component->properties['ADDITIONALATTRIBUTES'] = '';
				$component->properties['CAPTION'] = $field->publictitle;
				$component->properties['DESCRIPTION'] = $field->desc;
				$component->properties['ITEMS'] = $field->value;
				$component->properties['REQUIRED'] = $field->required ? 'YES' : 'NO';
				$component->properties['FLOW'] = $field->layoutoption ? 'HORIZONTAL' : 'VERTICAL';
				if ($field->disabled)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' disabled="disabled"';
				if ($field->onblur)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' onblur="'.$field->onblur.'"';
				if ($field->class)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' class="'.$field->class.'"';
				if ($field->style)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' style="'.$field->style.'"';
				
				if ($field->allowsetbyget)
				{
					$field->value = explode("\n", str_replace(array("\r\n", "\r"), "\n", $field->value));
					array_walk($field->value, array('self', '_addSlashes'));
					$field->value = implode("','", $field->value);
					
					$component->properties['ITEMS'] = "//<code>\n \$items = array('".$field->value."');\n return RSFormProHelper::checkValue(JRequest::getVar('".addslashes($component->properties['NAME'])."', '".addslashes($field->multiple)."'), \$items);\n//</code>";
				}
				
				self::_convertValidationRule($field, $component, $scripts);
			break;
			
			case 'hidden':
			case 'ipaddresshidden':
			case 'useremailaddresshidden':
			case 'userfullnamehidden':
			case 'useridhidden':
			case 'usernamehidden':
			case 'randomnumber':
			case 'timestamp':
			case 'referer':
			case 'embeddedpagetitle':
				$component->ComponentTypeId = 11;
				$component->properties['ADDITIONALATTRIBUTES'] = '';
				if ($field->disabled)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' disabled="disabled"';
					
				switch ($field->plugin)
				{
					default:
					case 'hidden':
						$component->properties['DEFAULTVALUE'] = $field->value;
						if ($field->allowsetbyget)
							$component->properties['DEFAULTVALUE'] = "//<code>\n return JRequest::getVar('".addslashes($component->properties['NAME'])."', '".addslashes($field->value)."');\n//</code>";
					break;
					case 'ipaddresshidden':
						$component->properties['DEFAULTVALUE'] = "//<code>\n return \$_SERVER['REMOTE_ADDR'];\n//</code>";
						if ($field->allowsetbyget)
							$component->properties['DEFAULTVALUE'] = "//<code>\n return JRequest::getVar('".addslashes($component->properties['NAME'])."', \$_SERVER['REMOTE_ADDR']);\n//</code>";
					break;
					case 'useremailaddresshidden':
						$component->properties['DEFAULTVALUE'] = "//<code>\n \$user = JFactory::getUser(); \n return \$user->get('email', '');\n//</code>";
						if ($field->allowsetbyget)
							$component->properties['DEFAULTVALUE'] = "//<code>\n \$user = JFactory::getUser(); \n return JRequest::getVar('".addslashes($component->properties['NAME'])."', \$user->get('email', '');\n//</code>";
					break;
					case 'userfullnamehidden':
						$component->properties['DEFAULTVALUE'] = "//<code>\n \$user = JFactory::getUser(); \n return \$user->get('name', '');\n//</code>";
						if ($field->allowsetbyget)
							$component->properties['DEFAULTVALUE'] = "//<code>\n \$user = JFactory::getUser(); \n return JRequest::getVar('".addslashes($component->properties['NAME'])."', \$user->get('name', '');\n//</code>";
					break;
					case 'useridhidden':
						$component->properties['DEFAULTVALUE'] = "//<code>\n \$user = JFactory::getUser(); \n return \$user->get('id', 0);\n//</code>";
						if ($field->allowsetbyget)
							$component->properties['DEFAULTVALUE'] = "//<code>\n \$user = JFactory::getUser(); \n return JRequest::getVar('".addslashes($component->properties['NAME'])."', \$user->get('id', 0);\n//</code>";
					break;
					case 'usernamehidden':
						$component->properties['DEFAULTVALUE'] = "//<code>\n \$user = JFactory::getUser(); \n return \$user->get('username', 'NOT LOGGED IN');\n//</code>";
						if ($field->allowsetbyget)
							$component->properties['DEFAULTVALUE'] = "//<code>\n \$user = JFactory::getUser(); \n return JRequest::getVar('".addslashes($component->properties['NAME'])."', \$user->get('username', 'NOT LOGGED IN');\n//</code>";
					break;
					case 'randomnumber':
						$component->properties['DEFAULTVALUE'] = "//<code>\n return rand(".str_replace(':', ',', $field->value).");\n//</code>";
						if ($field->allowsetbyget)
							$component->properties['DEFAULTVALUE'] = "//<code>\n return JRequest::getVar('".addslashes($component->properties['NAME'])."', rand(".str_replace(':', ',', $field->value)."));\n//</code>";
					break;
					case 'timestamp':
						$component->properties['DEFAULTVALUE'] = "//<code>\n return date('".addslashes($field->value)."');\n//</code>";
						if ($field->allowsetbyget)
							$component->properties['DEFAULTVALUE'] = "//<code>\n return JRequest::getVar('".addslashes($component->properties['NAME'])."', date('".addslashes($field->value)."'));\n//</code>";
					break;
					case 'referer':
						$component->properties['DEFAULTVALUE'] = "#HTTP_REFERER#";
						$scripts['display'][] = '$session = JFactory::getSession()';
						$scripts['display'][] = 'if ((!isset($_POST) || !isset($_POST[\'form\'])) && isset($_SERVER[\'HTTP_REFERER\'])) $session->set(\'com_rsform.referer\', $_SERVER[\'HTTP_REFERER\']);';
						$scripts['display'][] = '$formLayout = str_replace(\'"#HTTP_REFERER#"\', $session->get(\'com_rsform.referer\', \'\'), $formLayout);';
						
						if ($field->allowsetbyget)
							$scripts['display'][] = '$formLayout = str_replace(\'"#HTTP_REFERER#"\', JRequest::getVar(\''.addslashes($component->properties['NAME']).'\', $session->get(\'com_rsform.referer\', \'\')), $formLayout);';
						else
							$scripts['display'][] = '$formLayout = str_replace(\'"#HTTP_REFERER#"\', $session->get(\'com_rsform.referer\', \'\'), $formLayout);';
					break;
					case 'embeddedpagetitle':
						$component->properties['DEFAULTVALUE'] = "//<code>\n \$doc = JFactory::getDocument();\n return \$doc->getTitle();\n//</code>";
						if ($field->allowsetbyget)
							$component->properties['DEFAULTVALUE'] = "//<code>\n \$doc = JFactory::getDocument();\n return JRequest::getVar('".addslashes($component->properties['NAME'])."', \$doc->getTitle());\n//</code>";
					break;
				}
				
				self::_convertValidationRule($field, $component, $scripts);
			break;
			
			case 'useremailaddress':
			case 'userfullname':
			case 'userid':
			case 'username':
			case 'ipaddress':
			case 'textbox':
				$component->ComponentTypeId = 1;
				
				$component->properties['REQUIRED'] = $field->required ? 'YES' : 'NO';
				$component->properties['CAPTION'] = $field->publictitle;
				$component->properties['DESCRIPTION'] = $field->desc;
				$component->properties['ADDITIONALATTRIBUTES'] = '';
				if ($field->disabled)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' disabled="disabled"';
				if ($field->onblur)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' onblur="'.$field->onblur.'"';
				if ($field->class)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' class="'.$field->class.'"';
				if ($field->style)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' style="'.$field->style.'"';
				
				$component->properties['SIZE'] = $field->size;
				$component->properties['MAXSIZE'] = $field->maxlength;
				$component->properties['VALIDATIONRULE'] = 'none';
				self::_convertValidationRule($field, $component, $scripts);
				
				switch ($field->plugin)
				{
					default:
					case 'textbox':
						$component->properties['DEFAULTVALUE'] = $field->value;
						if ($field->allowsetbyget)
							$component->properties['DEFAULTVALUE'] = "//<code>\n return JRequest::getVar('".addslashes($component->properties['NAME'])."', '".addslashes($field->value)."');\n//</code>";
					break;
					
					case 'useremailaddress':
						$component->properties['DEFAULTVALUE'] = "//<code>\n \$user = JFactory::getUser(); \n return \$user->get('email', '');\n//</code>";
						if ($field->allowsetbyget)
							$component->properties['DEFAULTVALUE'] = "//<code>\n \$user = JFactory::getUser(); \n return JRequest::getVar('".addslashes($component->properties['NAME'])."', \$user->get('email', '');\n//</code>";
					break;

					case 'userfullname':
						$component->properties['DEFAULTVALUE'] = "//<code>\n \$user = JFactory::getUser(); \n return \$user->get('name', '');\n//</code>";
						if ($field->allowsetbyget)
							$component->properties['DEFAULTVALUE'] = "//<code>\n \$user = JFactory::getUser(); \n return JRequest::getVar('".addslashes($component->properties['NAME'])."', \$user->get('name', '');\n//</code>";
					break;
					
					case 'userid':
						$component->properties['DEFAULTVALUE'] = "//<code>\n \$user = JFactory::getUser(); \n return \$user->get('id', 0);\n//</code>";
						if ($field->allowsetbyget)
							$component->properties['DEFAULTVALUE'] = "//<code>\n \$user = JFactory::getUser(); \n return JRequest::getVar('".addslashes($component->properties['NAME'])."', \$user->get('id', 0);\n//</code>";
					break;
					
					case 'username':
						$component->properties['DEFAULTVALUE'] = "//<code>\n \$user = JFactory::getUser(); \n return \$user->get('username', 'NOT LOGGED IN');\n//</code>";
						if ($field->allowsetbyget)
							$component->properties['DEFAULTVALUE'] = "//<code>\n \$user = JFactory::getUser(); \n return JRequest::getVar('".addslashes($component->properties['NAME'])."', \$user->get('username', 'NOT LOGGED IN');\n//</code>";
					break;
					
					case 'ipaddress':
						$component->properties['DEFAULTVALUE'] = "//<code>\n return \$_SERVER['REMOTE_ADDR'];\n//</code>";
						if ($field->allowsetbyget)
							$component->properties['DEFAULTVALUE'] = "//<code>\n return JRequest::getVar('".addslashes($component->properties['NAME'])."', \$_SERVER['REMOTE_ADDR']);\n//</code>";
					break;
				}
				
				self::_convertValidationRule($field, $component, $scripts);
			break;
			
			case 'textarea':
				$component->ComponentTypeId = 2;
				
				$component->properties['REQUIRED'] = $field->required ? 'YES' : 'NO';
				$component->properties['CAPTION'] = $field->publictitle;
				$component->properties['DESCRIPTION'] = $field->desc;
				$component->properties['COLS'] = $field->cols;
				$component->properties['ROWS'] = $field->rows;
				$component->properties['VALIDATIONRULE'] = 'none';
				self::_convertValidationRule($field, $component, $scripts);
				
				$component->properties['ADDITIONALATTRIBUTES'] = '';
				if ($field->disabled)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' disabled="disabled"';
				if ($field->onblur)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' onblur="'.$field->onblur.'"';
				if ($field->class)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' class="'.$field->class.'"';
				if ($field->style)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' style="'.$field->style.'"';
				$component->properties['DEFAULTVALUE'] = $field->value;
				if ($field->allowsetbyget)
					$component->properties['DEFAULTVALUE'] = "//<code>\n return JRequest::getVar('".addslashes($component->properties['NAME'])."', '".addslashes($field->value)."');\n//</code>";
			break;
			
			case 'html':
				$component->ComponentTypeId = 10;
				
				$component->properties['DEFAULTVALUE'] = $field->value;
				if ($field->allowsetbyget)
					$component->properties['DEFAULTVALUE'] = "//<code>\n return JRequest::getVar('".addslashes($component->properties['NAME'])."', '".addslashes($field->value)."');\n//</code>";
			break;
			
			case 'submit':
				$component->ComponentTypeId = 13;
				
				$component->properties['LABEL'] = $field->value;
				$component->properties['ADDITIONALATTRIBUTES'] = '';
				if ($field->disabled)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' disabled="disabled"';
				if ($field->class)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' class="'.$field->class.'"';
				if ($field->style)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' style="'.$field->style.'"';
				if ($field->size)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' size="'.$field->size.'"';
			break;
			
			case 'select':
			case 'selectaustralianstates':
			case 'selectcanadianprovince':
			case 'selectcountries':
			case 'selectcurrency':
			case 'selectonetohundred':
			case 'selectrating':
			case 'selecttruefalse':
			case 'selectusastates':
			case 'selectyear':
				$component->ComponentTypeId = 3;
				
				$component->properties['REQUIRED'] = $field->required ? 'YES' : 'NO';
				$component->properties['MULTIPLE'] = $field->multiple ? 'YES' : 'NO';
				$component->properties['CAPTION'] = $field->publictitle;
				$component->properties['DESCRIPTION'] = $field->desc;
				$component->properties['ADDITIONALATTRIBUTES'] = '';
				if ($field->onblur)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' onblur="'.$field->onblur.'"';
				if ($field->disabled)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' disabled="disabled"';
				if ($field->class)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' class="'.$field->class.'"';
				if ($field->style)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' style="'.$field->style.'"';
				if ($field->size)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' size="'.$field->size.'"';
				
				if ($field->value)
					$field->params = RSFormProHelper::checkValue($field->value, $field->params);
				
				$component->properties['ITEMS'] = $field->params;
				
				// sql values
				if ($field->option2)
				{
					$component->properties['ITEMS'] = "//<code>\n \$db = JFactory::getDBO();\n \$db->setQuery(\"".$field->populatebysql."\"); return RSFormProHelper::createList(\$db->loadObjectList()); \n //</code>";
					
					if ($field->allowsetbyget)
						$component->properties['ITEMS'] = "//<code>\n \$db = JFactory::getDBO();\n \$db->setQuery(\"".$field->populatebysql."\"); return RSFormProHelper::checkValue(JRequest::getVar('".addslashes($component->properties['NAME'])."', '".addslashes($field->value)."'), RSFormProHelper::createList(\$db->loadObjectList())); \n //</code>";
				}
				if ($field->allowsetbyget)
				{
					$field->params = explode("\n", str_replace(array("\r\n", "\r"), "\n", $field->params));
					array_walk($field->params, array('self', '_addSlashes'));
					$field->params = implode("','", $field->params);
					
					$component->properties['ITEMS'] = "//<code>\n \$items = array('".$field->params."');\n return RSFormProHelper::checkValue(JRequest::getVar('".addslashes($component->properties['NAME'])."', '".addslashes($field->multiple)."'), \$items);\n//</code>";
				}
				
				self::_convertValidationRule($field, $component, $scripts);
			break;
			
			case 'password':
				$component->ComponentTypeId = 14;
				
				$component->properties['CAPTION'] = $field->publictitle;
				$component->properties['REQUIRED'] = $field->required ? 'YES' : 'NO';
				$component->properties['DESCRIPTION'] = $field->desc;
				$component->properties['SIZE'] = $field->size;
				$component->properties['MAXSIZE'] = $field->maxlength;
				$component->properties['VALIDATIONRULE'] = 'none';
				self::_convertValidationRule($field, $component, $scripts);
				$component->properties['ADDITIONALATTRIBUTES'] = '';
				if ($field->onblur)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' onblur="'.$field->onblur.'"';
				if ($field->disabled)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' disabled="disabled"';
				if ($field->class)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' class="'.$field->class.'"';
				if ($field->style)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' style="'.$field->style.'"';
				
				$component->properties['DEFAULTVALUE'] = $field->value;
				if ($field->allowsetbyget)
					$component->properties['DEFAULTVALUE'] = "//<code>\n return JRequest::getVar('".addslashes($component->properties['NAME'])."', '".addslashes($field->value)."');\n//</code>";
			break;
			
			case 'datepicker':
				$component->ComponentTypeId = 6;
				
				$component->properties['CAPTION'] = $field->publictitle;
				$component->properties['REQUIRED'] = $field->required ? 'YES' : 'NO';
				$component->properties['DESCRIPTION'] = $field->desc;
				$component->properties['CALENDARLAYOUT'] = 'POPUP';
				$component->properties['ADDITIONALATTRIBUTES'] = '';
				if ($field->onblur)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' onblur="'.$field->onblur.'"';
				if ($field->disabled)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' disabled="disabled"';
				if ($field->class)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' class="'.$field->class.'"';
				if ($field->style)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' style="'.$field->style.'"';
				$component->properties['DATEFORMAT'] = self::_getCalendarFormat($field->value);
				
				if ($field->allowsetbyget)
					$component->properties['DEFAULTVALUE'] = "//<code>\n return JRequest::getVar('".addslashes($component->properties['NAME'])."', '');\n//</code>";
			break;
			
			case 'fileupload':
				$component->ComponentTypeId = 9;
				
				$component->properties['CAPTION'] = $field->publictitle;
				$component->properties['REQUIRED'] = $field->required ? 'YES' : 'NO';
				$component->properties['DESCRIPTION'] = $field->desc;
				$component->properties['DESTINATION'] = $field->fileupload_destdir;
				if (self::_getMoveFiles())
					$component->properties['DESTINATION'] = JPATH_SITE.'/components/com_rsform/uploads';
				$component->properties['ADDITIONALATTRIBUTES'] = '';
				if ($field->onblur)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' onblur="'.$field->onblur.'"';
				if ($field->disabled)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' disabled="disabled"';
				if ($field->class)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' class="'.$field->class.'"';
				if ($field->style)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' style="'.$field->style.'"';
				if ($field->size)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' size="'.$field->size.'"';
				
				$component->properties['ACCEPTEDFILES'] = str_replace(',', "\n", $field->verify_fileupload_extensions);
				$component->properties['FILESIZE'] = $field->verify_fileupload_maxsize*1024;
			break;
			
			case 'pause':
				$component->ComponentTypeId = 7;
				
				$component->properties['LABEL'] = $field->value;
				$component->properties['ADDITIONALATTRIBUTES'] = '';
				if ($field->disabled)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' disabled="disabled"';
				if ($field->class)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' class="'.$field->class.'"';
				if ($field->style)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' style="'.$field->style.'"';
				if ($field->size)
					$component->properties['ADDITIONALATTRIBUTES'] .= ' size="'.$field->size.'"';
			break;
		}
		
		static $cache;
		if (!is_array($cache))
			$cache = array();
		
		if (!isset($cache[$component->ComponentTypeId]))
		{
			$db = JFactory::getDBO();
			$db->setQuery("SELECT `FieldName`, `FieldValues` FROM #__rsform_component_type_fields WHERE `ComponentTypeId`='".$component->ComponentTypeId."' ORDER BY `Ordering` ASC");
			$cache[$component->ComponentTypeId] = $db->loadObjectList();
		}
		foreach ($cache[$component->ComponentTypeId] as $item)
			if (!isset($component->properties[$item->FieldName]))
			{
				$item->FieldValues = RSFormProHelper::isCode($item->FieldValues);
				if (strpos($item->FieldValues, "\n") !== false)
					$item->FieldValues = reset(explode("\n", str_replace(array("\r\n", "\r"), "\n", $item->FieldValues)));
				
				$component->properties[$item->FieldName] = $lang->hasKey('RSFP_COMP_FVALUE_'.$item->FieldValues) ? JText::_('RSFP_COMP_FVALUE_'.$item->FieldValues) : $item->FieldValues;
			}
		
		return $component;
	}
	
	protected static function _convertValidationRule($field, &$component, &$scripts)
	{
		/*
		verify_isvalidukninumber
		verify_isvalidssn
		verify_isvalidukpostcode
		verify_isvalidvatnumber
		verify_brazil_cpf
		verify_brazil_cnpj
		verify_iban
		- not supported
		*/
		
		if ($field->verify_isexistingusername)
		{
			$scripts['process'][] = '$db->setQuery("SELECT id FROM #__users WHERE `username` LIKE \'".$db->escape($_POST[\'form\'][\''.addslashes($field->slug).'\'])."\'");';
			$scripts['process'][] = "if (!\$db->loadResult()) \$invalid[] = RSFormProHelper::getComponentId('".addslashes($field->slug)."');";
		}
		
		if ($field->verify_isnotexistingusername)
		{
			$scripts['process'][] = '$db->setQuery("SELECT id FROM #__users WHERE `username` LIKE \'".$db->escape($_POST[\'form\'][\''.addslashes($field->slug).'\'])."\'");';
			$scripts['process'][] = "if (\$db->loadResult()) \$invalid[] = RSFormProHelper::getComponentId('".addslashes($field->slug)."');";
		}
		
		if ($field->verify_isemailaddress)
			if (isset($component->properties['VALIDATIONRULE']))
				$component->properties['VALIDATIONRULE'] = 'email';
			
		if ($field->verify_isipaddress)
			if (isset($component->properties['VALIDATIONRULE']))
				$component->properties['VALIDATIONRULE'] = 'ipaddress';
			
		if ($field->verify_isvaliduszip)
			if (isset($component->properties['VALIDATIONRULE']))
				$component->properties['VALIDATIONRULE'] = 'uszipcode';
			
		if ($field->verify_isvalidcreditcardnumber)
			if (isset($component->properties['VALIDATIONRULE']))
				$component->properties['VALIDATIONRULE'] = 'creditcard';
			
		if ($field->verify_isvalidurl)
			if (isset($component->properties['VALIDATIONRULE']))
				$component->properties['VALIDATIONRULE'] = 'validurl';
		
		if ($field->verify_isalloweddomain)
		{
			$field->verify_isalloweddomain = explode(',', $field->verify_isalloweddomain);
			array_walk($field->verify_isalloweddomain, array('self', '_addSlashesAndTrim'));
			
			$scripts['process'][] = "\$domains = array('".implode("','", $field->verify_isalloweddomain)."');";
			$scripts['process'][] = "list(\$emailuser, \$domain) = explode('@', \$_POST['form']['".addslashes($field->slug)."'], 2)";
			$scripts['process'][] = 'if (!in_array(strtolower($domain), $domains))';
			$scripts['process'][] = "\$invalid[] = RSFormProHelper::getComponentId('".addslashes($field->slug)."');";
			if (isset($component->properties['VALIDATIONRULE']))
				$component->properties['VALIDATIONRULE'] = 'email';
		}
		
		if ($field->verify_isdenieddomain)
		{
			$field->verify_isdenieddomain = explode(',', $field->verify_isdenieddomain);
			array_walk($field->verify_isdenieddomain, array('self', '_addSlashesAndTrim'));
			
			$scripts['process'][] = "\$domains = array('".implode("','", $field->verify_isdenieddomain)."');";
			$scripts['process'][] = "list(\$emailuser, \$domain) = explode('@', \$_POST['form']['".addslashes($field->slug)."'], 2)";
			$scripts['process'][] = 'if (in_array(strtolower($domain), $domains))';
			$scripts['process'][] = "\$invalid[] = RSFormProHelper::getComponentId('".addslashes($field->slug)."');";
			if (isset($component->properties['VALIDATIONRULE']))
				$component->properties['VALIDATIONRULE'] = 'email';
		}
		
		if ($field->verify_isinteger)
			if (isset($component->properties['VALIDATIONRULE']))
				$component->properties['VALIDATIONRULE'] = 'numeric';
		
		if ($field->verify_stringlengthgreaterthan)
		{
			$scripts['process'][] = "if (strlen(\$_POST['form']['".addslashes($field->slug)."']) < ".(int) $field->verify_stringlengthgreaterthan.")";
			$scripts['process'][] = "\$invalid[] = RSFormProHelper::getComponentId('".addslashes($field->slug)."');";
		}
		
		if ($field->verify_stringlengthlessthan)
		{
			$scripts['process'][] = "if (strlen(\$_POST['form']['".addslashes($field->slug)."']) > ".(int) $field->verify_stringlengthlessthan.")";
			$scripts['process'][] = "\$invalid[] = RSFormProHelper::getComponentId('".addslashes($field->slug)."');";
		}
		
		if ($field->verify_stringlengthequals)
		{
			$scripts['process'][] = "if (strlen(\$_POST['form']['".addslashes($field->slug)."']) == ".(int) $field->verify_stringlengthequals.")";
			$scripts['process'][] = "\$invalid[] = RSFormProHelper::getComponentId('".addslashes($field->slug)."');";
		}
		
		if ($field->verify_numbergreaterthan)
		{
			$scripts['process'][] = "if (\$_POST['form']['".addslashes($field->slug)."'] <= '".$field->verify_numbergreaterthan."')";
			$scripts['process'][] = "\$invalid[] = RSFormProHelper::getComponentId('".addslashes($field->slug)."');";
			if (isset($component->properties['VALIDATIONRULE']))
				$component->properties['VALIDATIONRULE'] = 'numeric';
		}
		
		if ($field->verify_numberlessthan)
		{
			$scripts['process'][] = "if (\$_POST['form']['".addslashes($field->slug)."'] >= '".$field->verify_numberlessthan."')";
			$scripts['process'][] = "\$invalid[] = RSFormProHelper::getComponentId('".addslashes($field->slug)."');";
			if (isset($component->properties['VALIDATIONRULE']))
				$component->properties['VALIDATIONRULE'] = 'numeric';
		}
		
		if ($field->verify_numberequals)
		{
			$scripts['process'][] = "if (\$_POST['form']['".addslashes($field->slug)."'] == '".$field->verify_numberequals."')";
			$scripts['process'][] = "\$invalid[] = RSFormProHelper::getComponentId('".addslashes($field->slug)."');";
			if (isset($component->properties['VALIDATIONRULE']))
				$component->properties['VALIDATIONRULE'] = 'numeric';
		}
		
		if ($field->verify_regex)
		{
			if (isset($component->properties['VALIDATIONEXTRA']))
				$component->properties['VALIDATIONEXTRA'] = $field->verify_regex;
			if (isset($component->properties['VALIDATIONRULE']))
				$component->properties['VALIDATIONRULE'] = 'regex';
		}
		
		if ($field->verify_equalto)
		{
			if (isset($component->properties['VALIDATIONEXTRA']))
				$component->properties['VALIDATIONEXTRA'] = $field->verify_equalto;
			if (isset($component->properties['VALIDATIONRULE']))
				$component->properties['VALIDATIONRULE'] = 'numeric';
		}
		
		if ($field->verify_isinarray)
		{
			$field->verify_isinarray = explode(',', $field->verify_isinarray);
			array_walk($field->verify_isinarray, array('self', '_addSlashesAndTrim'));
			
			$scripts['process'][] = "\$values = array('".implode("','", $field->verify_isinarray)."');";
			$scripts['process'][] = 'if (!in_array($_POST[\'form\'][\''.addslashes($field->slug).'\'], $values))';
			$scripts['process'][] = "\$invalid[] = RSFormProHelper::getComponentId('".addslashes($field->slug)."');";
		}
	}
	
	protected static function _addSlashes(&$item, $key=0)
	{
		$item = addslashes($item);
		return $item;
	}
	
	protected static function _addSlashesAndTrim(&$item, $key=0)
	{
		$item = addslashes(trim($item));
		return $item;
	}
	
	protected static function _getCalendarFormat($format)
	{
		$js  = array('%m', '%d', '%Y');
		$php = array('mm', 'dd', 'yyyy');
		
		return str_replace($js, $php, $format);
	}
	
	protected static function _addComponent($component, $formId)
	{
		$db = JFactory::getDBO();
		$db->setQuery("INSERT INTO #__rsform_components SET FormId='".$formId."', `ComponentTypeId`='".$component->ComponentTypeId."', `Order`='".$component->Order."', `Published`='".$component->Published."'");
		$db->execute();
		
		$componentId = $db->insertid();
		if (is_array($component->properties))
			foreach ($component->properties as $property => $value)
			{
				$db->setQuery("INSERT INTO #__rsform_properties SET PropertyValue='".$db->escape($value)."', PropertyName='".$db->escape($property)."', ComponentId='".$componentId."'");
				$db->execute();
			}
		
		return $componentId;
	}
	
	protected static function _getSlugs($id)
	{
		static $cache = array();
		
		if (!isset($cache[$id])) {
			$db = JFactory::getDBO();
			$query = $db->getQuery(true)
						->select($db->qn('slug'))
						->from($db->qn('#__form_fields'))
						->where($db->qn('form_id') . ' = ' . $db->q($id));
			
			$cache[$id] = $db->setQuery($query)->loadColumn();
		}
		
		return $cache[$id];
	}
}