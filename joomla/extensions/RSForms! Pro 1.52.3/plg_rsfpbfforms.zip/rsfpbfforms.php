<?php
/**
* @package RSform!Pro
* @copyright (C) 2014 www.rsjoomla.com
* @license GPL, http://www.gnu.org/copyleft/gpl.html
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

class plgSystemRSFPBFForms extends JPlugin
{
	var $_message = array();
	
	public function __construct( &$subject, $config )
	{
		parent::__construct( $subject, $config );
		$this->loadLanguage('plg_system_rsfpbfforms');
		
		require_once dirname(__FILE__).'/helper.php';
	}
	
	protected function escape($string)
	{
		return RSFormProHelper::htmlEscape($string);
	}
	
	public function rsfp_bk_onSwitchTasks()
	{
		$task = JFactory::getApplication()->input->getCmd('plugin_task');
		if ($task == 'bfimport.form') {
			bfFormsImport::importForms();
		}
	}
	
	public function rsfp_bk_onAfterShowConfigurationTabs($tabs)
	{
		$tabs->addTitle(JText::_('RSFP_BFF_MIGRATION'), 'form-bffmigration');
		$tabs->addContent($this->migrationScreen());
	}
	
	protected function migrationScreen()
	{
		ob_start();
		
		RSFormProAssets::addScript(JUri::root(true).'/administrator/components/com_rsform/assets/js/bfimport.js');
		
		JText::script('RSFP_BFF_IMPORTING_FORM');
		JText::script('RSFP_BFF_DONE');
		
		if (!bfFormsImport::isInstalled()) { ?>
			<div class="alert alert-info"><?php echo JText::_('RSFP_BFF_NOT_INSTALLED'); ?></div>
		<?php } else {
			$forms = bfFormsImport::getForms();
		?>
			<div id="page-bfforms" class="com-rsform-css-fix">
				<?php if (!$forms) { ?>
					<p class="rsform_error"><?php echo JText::_('RSFP_BFF_MIGRATE_NO_FORMS'); ?></p>
				<?php } else { ?>
					<?php if (bfFormsImport::hasAkismet()) { ?>
						<p class="rsform_error"><?php echo JText::_('RSFP_AKISMET_WARNING'); ?></p>
					<?php } ?>
					<?php if (bfFormsImport::hasMailChimp()) { ?>
						<p class="rsform_error"><?php echo JText::_('RSFP_MAILCHIMP_WARNING'); ?></p>
					<?php } ?>
					<?php if (bfFormsImport::hasSalesforce()) { ?>
						<p class="rsform_error"><?php echo JText::_('RSFP_SALESFORCE_WARNING'); ?></p>
					<?php } ?>
					<table class="admintable table table-bordered">
						<tr>
							<td width="200" style="width: 200px;" align="right" class="key"><label><span class="hasTip" title="<?php echo JText::_('RSFP_BFF_MIGRATE_FORMS_DESC'); ?>"><?php echo JText::_('RSFP_BFF_MIGRATE_FORMS'); ?></span></label></td>
							<td>
							<?php foreach ($forms as $form) { ?>
								<p><input type="checkbox" name="bfforms[]" id="bfforms<?php echo $form->id; ?>" checked="checked" value="<?php echo $form->id; ?>" /> <label for="bfforms<?php echo $form->id; ?>"><?php echo $this->escape($form->form_name); ?></label></p>
							<?php } ?>
							</td>
						</tr>
						<tr>
							<td width="200" style="width: 200px;" align="right" class="key"><label><?php echo JText::_('RSFP_BFF_MIGRATE_SUBMISSIONS'); ?></label></td>
							<td><?php echo JHtml::_('select.booleanlist', 'bfsubmissions', null, 1); ?></td>
						</tr>
						<tr>
							<td width="200" style="width: 200px;" align="right" class="key"><label><?php echo JText::_('RSFP_BFF_SPAM_WHAT'); ?></label></td>
							<td><?php echo JHtml::_('select.booleanlist', 'bfcaptcha', null, 1, JText::_('RSFP_BFF_CONVERT_CAPTCHA'), JText::_('RSFP_BFF_KEEP_HIDDEN_FIELDS')); ?></td>
						</tr>
						<tr>
							<td width="200" style="width: 200px;" align="right" class="key"><label><?php echo JText::_('RSFP_BFF_MOVE_FILES'); ?></label></td>
							<td><?php echo JHtml::_('select.booleanlist', 'bfmovefiles', null, 1); ?></td>
						</tr>
					</table>
					<button id="bfimport" onclick="bfImport();" type="button" class="rs_button"><?php echo JText::_('RSFP_BFF_IMPORT'); ?></button><img id="rsloading" style="display: none;" src="components/com_rsform/assets/images/loading.gif" alt="Loading" /> <span style="font-weight: bold" id="rsstatus"></span>
					
					<input type="hidden" name="formId" value="0" id="formId" />
					<input type="hidden" name="limitstart" value="0" id="limitstart" />
				<?php } ?>
			</div>
		<?php
		}
		
		$contents = ob_get_contents();
		ob_end_clean();
		return $contents;
	}
}