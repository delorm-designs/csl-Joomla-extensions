function bfImport()
{
	var bfforms = document.getElementsByName('bfforms[]');
	for (var i=0; i<bfforms.length; i++)
		bfforms[i].disabled = true;
	document.getElementById('bfsubmissions0').disabled = true;
	document.getElementById('bfsubmissions1').disabled = true;
	document.getElementById('bfcaptcha0').disabled = true;
	document.getElementById('bfcaptcha1').disabled = true;
	document.getElementById('bfmovefiles0').disabled = true;
	document.getElementById('bfmovefiles1').disabled = true;
	document.getElementById('bfimport').style.display = 'none';
	document.getElementById('rsloading').style.display = '';
	
	for (var i=0; i<bfforms.length; i++)
	{
		if (bfforms[i].checked == false)
			continue;
		
		document.getElementById('rsstatus').innerHTML = Joomla.JText._('RSFP_BFF_IMPORTING_FORM').replace('\%d', bfforms[i].value);
		
		var todo = 'repeat';
		while(todo == 'repeat')
			todo = bfImportForms(bfforms[i].value);
		
		document.getElementById('formId').value = '0';
		document.getElementById('limitstart').value = '0';
	}
	
	for (var i=0; i<bfforms.length; i++)
		bfforms[i].disabled = false;
	document.getElementById('bfsubmissions0').disabled = false;
	document.getElementById('bfsubmissions1').disabled = false;
	document.getElementById('bfcaptcha0').disabled = false;
	document.getElementById('bfcaptcha1').disabled = false;
	document.getElementById('bfmovefiles0').disabled = false;
	document.getElementById('bfmovefiles1').disabled = false;
	document.getElementById('bfimport').style.display = '';
	document.getElementById('rsloading').style.display = 'none';
	
	document.getElementById('rsstatus').innerHTML = '<img src="components/com_rsform/assets/images/icons/ok.png" alt="" /> ' + Joomla.JText._('RSFP_BFF_DONE');
}

function bfImportForms(bfid)
{
	var xml = buildXmlHttp();
	var url = 'index.php?option=com_rsform&task=plugin&plugin_task=bfimport.form&randomTime=' + Math.random();
	xml.open("POST", url, false);
	
	params = new Array();
	params.push('id=' + bfid);
	if (document.getElementById('bfsubmissions1').checked == true)
		params.push('bfsubmissions=1');
	if (document.getElementById('bfcaptcha1').checked == true)
		params.push('bfcaptcha=1');
	if (document.getElementById('bfmovefiles1').checked == true)
		params.push('bfmovefiles=1');
	params.push('formId=' + document.getElementById('formId').value);
	params.push('limitstart=' + document.getElementById('limitstart').value);
	params = params.join('&');
	
	//Send the proper header information along with the request
	xml.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xml.setRequestHeader("Content-length", params.length);
	xml.setRequestHeader("Connection", "close");
	xml.send(params);
	
	if (xml.responseXML)
	{
		try {
			var action = xml.responseXML.getElementsByTagName('action')[0].firstChild.nodeValue;
			var formId = xml.responseXML.getElementsByTagName('formId')[0].firstChild.nodeValue;
			var limitstart = xml.responseXML.getElementsByTagName('limitstart')[0].firstChild.nodeValue;
		}
		catch (err) {
			var action = xml.responseText.indexOf('repeat') > -1 ? 'repeat' : 'stop';
			var matches = xml.responseText.match(/<formId>([0-9]+)<\/formId>/);
			var formId = matches[1];
			var matches = xml.responseText.match(/<limitstart>([0-9]+)<\/limitstart>/);
			var limitstart = matches[1];
		}
	}
	else // fail-safe method
	{
		try {
			var action = xml.responseText.indexOf('repeat') > -1 ? 'repeat' : 'stop';
			var matches = xml.responseText.match(/<formId>([0-9]+)<\/formId>/);
			var formId = matches[1];
			var matches = xml.responseText.match(/<limitstart>([0-9]+)<\/limitstart>/);
			var limitstart = matches[1];
		}
		catch (err) {
			// default to stop...
			action = 'stop';
		}
	}
	
	document.getElementById('formId').value = formId;
	document.getElementById('limitstart').value = limitstart;
	
	return action;
}