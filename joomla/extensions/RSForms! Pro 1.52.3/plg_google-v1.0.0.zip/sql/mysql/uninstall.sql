DELETE FROM #__rsform_config WHERE SettingName = 'google.code';
