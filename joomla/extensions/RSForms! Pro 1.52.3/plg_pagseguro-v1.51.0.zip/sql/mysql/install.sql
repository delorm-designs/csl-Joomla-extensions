INSERT IGNORE INTO `#__rsform_component_types` (`ComponentTypeId`, `ComponentTypeName`) VALUES (502, 'pagseguro');

DELETE FROM #__rsform_component_type_fields WHERE ComponentTypeId = 502;
INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES
(502, 'NAME', 'textbox', '', 0),
(502, 'LABEL', 'textbox', '', 1),
(502, 'COMPONENTTYPE', 'hidden', '502', 2),
(502, 'LAYOUTHIDDEN', 'hiddenparam', 'YES', 7);

INSERT IGNORE INTO `#__rsform_config` (`SettingName`, `SettingValue`) VALUES
('pagseguro.email', ''),
('pagseguro.token', ''),
('pagseguro.mode', '1');