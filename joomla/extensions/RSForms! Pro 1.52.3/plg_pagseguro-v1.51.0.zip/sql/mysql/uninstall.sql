DELETE FROM #__rsform_component_types WHERE ComponentTypeId = 502;
DELETE FROM #__rsform_component_type_fields WHERE ComponentTypeId = 502;

DELETE FROM #__rsform_config WHERE SettingName = 'pagseguro.email';
DELETE FROM #__rsform_config WHERE SettingName = 'pagseguro.token';
DELETE FROM #__rsform_config WHERE SettingName = 'pagseguro.mode';
