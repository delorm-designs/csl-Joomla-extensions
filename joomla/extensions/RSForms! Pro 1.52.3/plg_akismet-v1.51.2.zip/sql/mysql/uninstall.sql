DROP TABLE IF EXISTS `#__rsform_akismet`;
DELETE FROM #__rsform_config WHERE SettingName = 'aki.key';
