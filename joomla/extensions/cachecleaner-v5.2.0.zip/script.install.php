<?php
/**
 * @package         Regular Labs Installer
 * @version         16.8.1269
 * 
 * @author          Peter van Westen <info@regularlabs.com>
 * @link            http://www.regularlabs.com
 * @copyright       Copyright © 2016 Regular Labs All Rights Reserved
 * @license         http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

defined('_JEXEC') or die;

if (!class_exists('RegularLabsInstaller'))
{
	require_once __DIR__ . '/script.helper.php';
}

class PlgSystemRegularLabsInstallerCachecleanerInstallerScript extends RegularLabsInstaller
{
	var $dir           = null;
	var $installerName = 'regularlabsinstallercachecleaner';

	public function __construct()
	{
		$this->dir = __DIR__;
	}
}
