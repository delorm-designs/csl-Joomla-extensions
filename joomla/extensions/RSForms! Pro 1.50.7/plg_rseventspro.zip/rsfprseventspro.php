<?php
/**
* @version 1.3.0
* @package RSform!Pro 1.3.0
* @copyright (C) 2007-2010 www.rsjoomla.com
* @license GPL, http://www.gnu.org/copyleft/gpl.html
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );

/**
 * RSForm! Pro system plugin
 */
	
class plgSystemRSFPRSEventspro extends JPlugin {
	/**
	 * Constructor
	 *
	 *
	 * @access	protected
	 * @param	object	$subject The object to observe
	 * @param 	array   $config  An array that holds the plugin configuration
	 * @since	1.0
	 */
	public function __construct( &$subject, $config ) {
		parent::__construct( $subject, $config );
		$this->newComponents = array(30,31,32,33,34);
	}
	
	protected function canRun() {
		if (file_exists(JPATH_ADMINISTRATOR.'/components/com_rsform/helpers/rsform.php') && file_exists(JPATH_SITE.'/components/com_rseventspro/helpers/rseventspro.php')) {
			$lang = JFactory::getLanguage();
			$lang->load('plg_system_rsfprseventspro');
			
			require_once JPATH_ADMINISTRATOR.'/components/com_rsform/helpers/rsform.php';
			require_once JPATH_SITE.'/components/com_rseventspro/helpers/rseventspro.php';
			return true;
		}
		
		return false;
	}
	
	/*
		Event Triggered Functions
	*/
	public function rsfp_bk_onAfterShowComponents() {
		if (!self::canRun()) return;
		
		$html = '';
		$html .= '<li class="rsform_navtitle">'.JText::_('RSFP_RSEPRO_LABEL').'</li>';
		$html .= '<li><a href="javascript: void(0);" onclick="displayTemplate(30);return false;" id="rsfpc30"><span id="textbox">'.JText::_('RSFP_RSEPRO_NAME').'</span></a></li>';
		$html .= '<li><a href="javascript: void(0);" onclick="displayTemplate(31);return false;" id="rsfpc31"><span id="textbox">'.JText::_('RSFP_RSEPRO_EMAIL').'</span></a></li>';
		$html .= '<li><a href="javascript: void(0);" onclick="displayTemplate(32);return false;" id="rsfpc32"><span id="rseprotickets">'.JText::_('RSFP_RSEPRO_TICKETS').'</span></a></li>';
		$html .= '<li><a href="javascript: void(0);" onclick="displayTemplate(33);return false;" id="rsfpc33"><span id="dropdown">'.JText::_('RSFP_RSEPRO_PAYMENTS').'</span></a></li>';
		$html .= '<li><a href="javascript: void(0);" onclick="displayTemplate(34);return false;" id="rsfpc34"><span id="textbox">'.JText::_('RSFP_RSEPRO_COUPON').'</span></a></li>';
		
		echo $html;
	}
	
	public function rsfp_f_onBeforeFormValidation($args) {
		if (!self::canRun()) return;
		
		$jinput	= JFactory::getApplication()->input;
		$form   = $jinput->get('form',array(),'array');
		$formId = (int) $form['formId'];
		
		$exists = RSFormProHelper::componentExists($formId, $this->newComponents);
		if (!empty($exists)) {
			$db 	= JFactory::getDbo();
			$query	= $db->getQuery(true);
			$cid 	= $jinput->getInt('cid');
			
			if ($cid && $jinput->get('option') == 'com_rseventspro' && $this->_getHasForm($cid, $formId)) {
				$query->clear()
					->select('COUNT('.$db->qn('id').')')
					->from($db->qn('#__rseventspro_users'))
					->where($db->qn('ide').' = '.$cid)
					->where($db->qn('email').' = '.$db->q($form['RSEProEmail']));
				
				$db->setQuery($query);
				$registered = $db->loadResult();
				
				$multiplereg = rseventsproHelper::getConfig('multi_registration');
				if ($registered && $multiplereg == 0) {
					JError::raiseWarning(500, JText::_('RSEPRO_REGISTRATION_ERROR5'));
					$args['invalid'][] = $this->_getComponentId('RSEProEmail', $formId);
				}
			}
		}
	}
	
	public function rsfp_f_onAfterFormProcess($args) {
		if (!self::canRun()) return;
		
		$exists = RSFormProHelper::componentExists($args['formId'], $this->newComponents);
		if (!empty($exists)) {			
			$db 	= JFactory::getDbo();
			$query	= $db->getQuery(true);
			$jinput	= JFactory::getApplication()->input;
			$cid 	= $jinput->getInt('cid');
			$total	= 0;
			
			if ($cid && $jinput->get('option') == 'com_rseventspro' && $this->_getHasForm($cid, $args['formId'])) {
				$result = rseventsproHelper::saveRegistration($args['SubmissionId']);
				
				// Get tickets value from RSForm!Pro
				$query->clear()
					->select($db->qn('SubmissionValueId'))->select($db->qn('FieldValue'))
					->from($db->qn('#__rsform_submission_values'))
					->where($db->qn('FormId').' = '.(int) $args['formId'])
					->where($db->qn('SubmissionId').' = '.(int) $args['SubmissionId'])
					->where($db->qn('FieldName').' = '.$db->q('RSEProTickets'));
				
				$db->setQuery($query);
				$submission = $db->loadObject();
				
				$query->clear()
					->select($db->qn('id'))
					->select($db->qn('discount'))->select($db->qn('early_fee'))
					->select($db->qn('late_fee'))->select($db->qn('tax'))
					->from($db->qn('#__rseventspro_users'))
					->where($db->qn('SubmissionId').' = '.(int) $args['SubmissionId']);
				
				$db->setQuery($query);
				$paymentInfo = $db->loadObject();
				
				$query->clear()
					->select($db->qn('t.price'))->select($db->qn('ut.quantity'))
					->from($db->qn('#__rseventspro_tickets','t'))
					->join('left', $db->qn('#__rseventspro_user_tickets','ut').' ON '.$db->qn('ut.idt').' = '.$db->qn('t.id'))
					->where($db->qn('ut.ids').' = '.$paymentInfo->id);
				
				$db->setQuery($query);
				$usertickets = $db->loadObjectList();
				
				if (!empty($usertickets)) {
					foreach ($usertickets as $userticket) {
						if ($userticket->price)
							$total += $userticket->quantity * $userticket->price;
					}
					
					if (!empty($paymentInfo->discount))
						$total = $total - $paymentInfo->discount;
						
					if (!empty($paymentInfo->early_fee))
						$total = $total - $paymentInfo->early_fee;
					
					if (!empty($paymentInfo->late_fee))
						$total = $total + $paymentInfo->late_fee;
					
					if (!empty($paymentInfo->tax))
						$total = $total + $paymentInfo->tax;
				}
				
				if ($total) {
					$oldticketstext = $submission->FieldValue.' , '.JText::_('COM_RSEVENTSPRO_GLOBAL_TOTAL').': '.rseventsproHelper::currency($total);
					$query->clear()
						->update($db->qn('#__rsform_submission_values'))
						->set($db->qn('FieldValue').' = '.$db->q($oldticketstext))
						->where($db->qn('SubmissionValueId').' = '.$db->q($submission->SubmissionValueId));
					
					$db->setQuery($query);
					$db->execute();
				}
				
				$form = $jinput->get('form',array(),'array');
				if ($form['RSEProName']) {
					$hasPrice = 0;
					$tickets = $jinput->get('tickets',array(),'array');
					
					if (empty($tickets)) {
						$query->clear()
							->select($db->qn('price'))
							->from($db->qn('#__rseventspro_tickets'))
							->where($db->qn('id').' = '.(int) $form['RSEProTickets']);
						
						$db->setQuery($query);
						if ($db->loadResult() > 0) $hasPrice = 1;
					} else {
						foreach ($tickets as $ticket => $quantity) {
							$query->clear()
								->select($db->qn('price'))
								->from($db->qn('#__rseventspro_tickets'))
								->where($db->qn('id').' = '.(int) $ticket);
							
							$db->setQuery("SELECT price FROM #__rseventspro_tickets WHERE id = ".(int) $ticket." ");
							if ($db->loadResult() > 0) $hasPrice = 1;
						}
					}
					
					if ($hasPrice) {
						echo rseventsproHelper::redirect(true,$result['message'],$result['url'],true);
						exit();
					}
				}
			}
		}
	}
	
	public function rsfp_f_onBeforeStoreSubmissions($args) {
		if (!self::canRun()) return;
		
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);
		$jinput	= JFactory::getApplication()->input;
		$post	=& $args['post'];
		
		$multipleTickets = rseventsproHelper::getConfig('multi_tickets');
		$thestring = '';
		
		if ($multipleTickets) {
			$tickets = $jinput->get('tickets',array(),'array');
			
			if (!empty($tickets)) {
				$tmp = array();
				foreach ($tickets as $ticket => $quantity) {
					$query->clear()
						->select($db->qn('name'))->select($db->qn('price'))
						->from($db->qn('#__rseventspro_tickets'))
						->where($db->qn('id').' = '.(int) $ticket);
					
					$db->setQuery($query);
					$ticketDetails = $db->loadObject();
					$ticketno = $quantity < 0 ? 1 : $quantity;
					
					if ($ticketDetails->price)
						$tmp[] = $ticketno.' x '.$ticketDetails->name.' ('.rseventsproHelper::currency($ticketDetails->price).')';
					else 
						$tmp[] = $ticketno.' x '.$ticketDetails->name.' ('.JText::_('COM_RSEVENTSPRO_GLOBAL_FREE').')';
				}
				
				$thestring .= !empty($tmp) ? implode(' , ',$tmp) : '';
			} else {
				$ticket = $post['RSEProTickets'];
				
				$query->clear()
					->select($db->qn('name'))->select($db->qn('price'))
					->from($db->qn('#__rseventspro_tickets'))
					->where($db->qn('id').' = '.(int) $ticket);
				
				$db->setQuery($query);
				$ticketDetails = $db->loadObject();
				
				$quantity = $jinput->getInt('from',0) == 1 ? $jinput->getInt('number') : $jinput->getInt('numberinp');
				$quantity = !empty($quantity) ? (int) $quantity : 1;
				
				if ($ticketDetails->price)
					$thestring .= $quantity.' x '.$ticketDetails->name.' ('.rseventsproHelper::currency($ticketDetails->price).')';
				else 
					$thestring .= $quantity.' x '.$ticketDetails->name.' ('.JText::_('COM_RSEVENTSPRO_GLOBAL_FREE').')';
			}
		} else {
			$ticket = $post['RSEProTickets'];
			$query->clear()
				->select($db->qn('name'))->select($db->qn('price'))
				->from($db->qn('#__rseventspro_tickets'))
				->where($db->qn('id').' = '.(int) $ticket);
			
			$db->setQuery($query);
			$ticketDetails = $db->loadObject();
			
			$quantity = $jinput->getInt('from',0) == 1 ? $jinput->getInt('number') : $jinput->getInt('numberinp');
			$quantity = !empty($quantity) ? (int) $quantity : 1;
			
			if ($ticketDetails->price)
				$thestring .= $quantity.' x '.$ticketDetails->name.' ('.rseventsproHelper::currency($ticketDetails->price).')';
			else 
				$thestring .= $quantity.' x '.$ticketDetails->name.' ('.JText::_('COM_RSEVENTSPRO_GLOBAL_FREE').')';
		}
		
		$post['RSEProTickets'] = $thestring;
		
		$payment = $post['RSEProPayment'];
		$payment = is_array($payment) ? $payment[0] : $payment;
		$post['RSEProPayment'] = rseventsproHelper::getPayment($payment);
	}
	
	protected function _getHasForm($ide, $formId) {
		if (!self::canRun()) return;
		
		static $cache;
		if (!isset($cache[$formId])) {
			$db		= JFactory::getDbo();
			$query	= $db->getQuery(true);
			
			$query->clear()
				->select('COUNT('.$db->qn('id').')')
				->from($db->qn('#__rseventspro_events'))
				->where($db->qn('form').' = '.(int) $formId)
				->where($db->qn('id').' = '.(int) $ide);
			
			$db->setQuery($query);
			$cache[$formId] = $db->loadResult();
		}
		
		return $cache[$formId];
	}
	
	protected function _getComponentId($name, $formId) {
		if (!self::canRun()) return;
		
		if (method_exists('RSFormProHelper', 'getComponentId'))
			return RSFormProHelper::getComponentId($name, $formId);
		
		static $cache;
		if (!is_array($cache))
			$cache = array();
			
		if (empty($formId)) {
			$formId = JFactory::getApplication()->input->getInt('formId');
			if (empty($formId)) {
				$post   = JFactory::getApplication()->input->get('form',array(),'array');
				$formId = (int) @$post['formId'];
			}
		}
		
		if (!isset($cache[$formId][$name]))
			$cache[$formId][$name] = RSFormProHelper::componentNameExists($name, $formId);
		
		return $cache[$formId][$name];
	}
	
	public function getPayments() {
		if (!self::canRun()) return;
		
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);
		$jinput	= JFactory::getApplication()->input;
		
		if ($jinput->get('option') != 'com_rseventspro' && $jinput->get('layout') != 'subscribe') 
			return;
		
		$cid		= $jinput->getInt('cid');
		$payments	= array();
		
		$query->clear()
			->select($db->qn('payments'))
			->from($db->qn('#__rseventspro_events'))
			->where($db->qn('id').' = '.$cid);
		
		$db->setQuery($query);
		$eventPayments	= $db->loadResult();
		$payment_items	= rseventsproHelper::getPayments(false,$eventPayments);
		$default_payment= rseventsproHelper::getConfig('default_payment');
		
		if (!empty($payment_items)) {
			foreach ($payment_items as $payment) {
				$default = $default_payment == $payment->value ? '[c]' : '';
				$payments[] = $payment->value.'|'.$payment->text.$default;
			}
		}
		
		if (!empty($payments))
			return implode("\n",$payments);
		
		return '';
	}
	
	public function getTickets() {
		if (!self::canRun()) return;
		
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);
		$jinput	= JFactory::getApplication()->input;
		
		if ($jinput->get('option') != 'com_rseventspro' && $jinput->get('layout') != 'subscribe') return;

		$cid	  = $jinput->getInt('cid');
		$return   = array();
		
		$query->clear()
			->select('*')
			->from($db->qn('#__rseventspro_tickets'))
			->where($db->qn('ide').' = '.$cid);
		
		$db->setQuery($query);
		$tickets = $db->loadObjectList();
		
		if (!empty($tickets)) {
			foreach ($tickets as $ticket) {
				$checkticket = rseventsproHelper::checkticket($ticket->id);				
				if ($checkticket == -1) continue;
				
				$price = $ticket->price > 0 ? ' - '.rseventsproHelper::currency($ticket->price) : ' - '.JText::_('COM_RSEVENTSPRO_GLOBAL_FREE');
				$return[] = $ticket->id.'|'.$ticket->name.$price;
			}
		}
		
		if (!empty($return))
			return implode("\n",$return);
		
		return;
	}
	
	public function getName() {
		if (!self::canRun()) return;
		
		$uid = JFactory::getUser()->get('id');
		return rseventsproHelper::getUser($uid);
	}
	
	public function rsfp_beforeUserEmail($args) {
		$jinput = JFactory::getApplication()->input;
		
		if ($jinput->getCmd('option') == 'com_rseventspro' || $jinput->getCmd('layout') == 'subscribe') {
			$subjecttext	= $this->placeholders(array('subject' => $args['userEmail']['subject'], 'body' => $args['userEmail']['text']),$jinput->getInt('cid'),'');
			$toreplyto		= $this->placeholders(array('subject' => $args['userEmail']['to'], 'body' => $args['userEmail']['replyto']),$jinput->getInt('cid'),'');
			$ccbcc			= $this->placeholders(array('subject' => $args['userEmail']['cc'], 'body' => $args['userEmail']['bcc']),$jinput->getInt('cid'),'');
			$fromfromName	= $this->placeholders(array('subject' => $args['userEmail']['from'], 'body' => $args['userEmail']['fromName']),$jinput->getInt('cid'),'');
			
			$args['userEmail']['text'] = $subjecttext['body'];
			$args['userEmail']['subject'] = $subjecttext['subject'];
			
			$args['userEmail']['to'] = $toreplyto['subject'];
			$args['userEmail']['replyto'] = $toreplyto['body'];
			
			$args['userEmail']['cc'] = $ccbcc['subject'];
			$args['userEmail']['bcc'] = $ccbcc['body'];
			
			$args['userEmail']['from'] = $fromfromName['subject'];
			$args['userEmail']['fromName'] = $fromfromName['body'];
		}
	}
	
	public function rsfp_beforeAdminEmail($args) {
		$jinput = JFactory::getApplication()->input;
		
		if ($jinput->getCmd('option') == 'com_rseventspro' || $jinput->getCmd('layout') == 'subscribe') {
			$subjecttext	= $this->placeholders(array('subject' => $args['adminEmail']['subject'], 'body' => $args['adminEmail']['text']),$jinput->getInt('cid'),'');
			$toreplyto		= $this->placeholders(array('subject' => $args['adminEmail']['to'], 'body' => $args['adminEmail']['replyto']),$jinput->getInt('cid'),'');
			$ccbcc			= $this->placeholders(array('subject' => $args['adminEmail']['cc'], 'body' => $args['adminEmail']['bcc']),$jinput->getInt('cid'),'');
			$fromfromName	= $this->placeholders(array('subject' => $args['adminEmail']['from'], 'body' => $args['adminEmail']['fromName']),$jinput->getInt('cid'),'');
			
			$args['adminEmail']['text'] = $subjecttext['body'];
			$args['adminEmail']['subject'] = $subjecttext['subject'];
			
			$args['adminEmail']['to'] = $toreplyto['subject'];
			$args['adminEmail']['replyto'] = $toreplyto['body'];
			
			$args['adminEmail']['cc'] = $ccbcc['subject'];
			$args['adminEmail']['bcc'] = $ccbcc['body'];
			
			$args['adminEmail']['from'] = $fromfromName['subject'];
			$args['adminEmail']['fromName'] = $fromfromName['body'];
		}
	}
	
	public function rsfp_beforeAdditionalEmail($args) {
		$jinput = JFactory::getApplication()->input;
		if ($jinput->getCmd('option') == 'com_rseventspro' || $jinput->getCmd('layout') == 'subscribe') {
			$subjecttext	= $this->placeholders(array('subject' => $args['additionalEmail']['subject'], 'body' => $args['additionalEmail']['text']),$jinput->getInt('cid'),'');
			$toreplyto		= $this->placeholders(array('subject' => $args['additionalEmail']['to'], 'body' => $args['additionalEmail']['replyto']),$jinput->getInt('cid'),'');
			$ccbcc			= $this->placeholders(array('subject' => $args['additionalEmail']['cc'], 'body' => $args['additionalEmail']['bcc']),$jinput->getInt('cid'),'');
			$fromfromName	= $this->placeholders(array('subject' => $args['additionalEmail']['from'], 'body' => $args['additionalEmail']['fromName']),$jinput->getInt('cid'),'');
			
			$args['additionalEmail']['text'] = $subjecttext['body'];
			$args['additionalEmail']['subject'] = $subjecttext['subject'];
			
			$args['additionalEmail']['to'] = $toreplyto['subject'];
			$args['additionalEmail']['replyto'] = $toreplyto['body'];
			
			$args['additionalEmail']['cc'] = $ccbcc['subject'];
			$args['additionalEmail']['bcc'] = $ccbcc['body'];
			
			$args['additionalEmail']['from'] = $fromfromName['subject'];
			$args['additionalEmail']['fromName'] = $fromfromName['body'];
		}
	}
	
	public function rsfp_f_onAfterShowThankyouMessage($args) {
		$jinput = JFactory::getApplication()->input;
		if ($jinput->getCmd('option') == 'com_rseventspro' || $jinput->getCmd('layout') == 'subscribe') {
			$db  	= JFactory::getDbo();
			$query	= $db->getQuery(true);
			$cid 	= $jinput->getInt('cid');
			
			$query->clear()
				->select($db->qn('name'))
				->from($db->qn('#__rseventspro_events'))
				->where($db->qn('id').' = '.$cid);
			
			$db->setQuery($query);
			$name = $db->loadResult();
			
			$text = $args['output'];
			$text = $this->placeholders($text,$cid,'');
			
			if (rseventsproHelper::getConfig('modal') == 0) {			
				$replace = '<a class="btn button" href="'.rseventsproHelper::route('index.php?option=com_rseventspro&layout=show&id='.rseventsproHelper::sef($cid,$name)).'">'.JText::_('COM_RSEVENTSPRO_GLOBAL_BACK').'</a>';
				$pattern	= '#<input type="button" class="rsform-submit-button" name="continue"(.*?)/>#is';
				preg_match($pattern,$text,$match);
				
				if (empty($match))
					$text .= '<br />'.$replace;
				else 
					$text = preg_replace($pattern,$replace,$text);
			}
			
			$args['output'] = $text;
		}
	}
	
	public function rsfp_f_onInitFormDisplay($args) {
		$jinput = JFactory::getApplication()->input;
		if ($jinput->getCmd('option') == 'com_rseventspro' || $jinput->getCmd('layout') == 'subscribe') {		
			$text = $args['formLayout'];
			$text = $this->placeholders($text,$jinput->getInt('cid'),'');
			$args['formLayout'] = $text;
		}
	}
	
	public function rsfp_bk_onBeforeCreateFrontComponentBody($args) {
		$jinput = JFactory::getApplication()->input;
		if ($jinput->getCmd('option') == 'com_rseventspro' && $jinput->getCmd('layout') == 'subscribe') {
			if (!empty($args['data']['DEFAULTVALUE'])) {
				$defaulttext = $args['data']['DEFAULTVALUE'];
				$defaulttext = $this->placeholders($defaulttext,$jinput->getInt('cid'),'');
				$args['data']['DEFAULTVALUE'] = $defaulttext;
			}
			
			if (!empty($args['data']['TEXT'])) {
				$text = $args['data']['TEXT'];
				$text = $this->placeholders($text,$jinput->getInt('cid'),'');
				$args['data']['TEXT'] = $text;
			}
			
			if ($args['data']['NAME'] == 'RSEProPayment') {
				if (empty($args['data']['ADDITIONALATTRIBUTES'])) {
					$args['data']['ADDITIONALATTRIBUTES'] = 'onchange="rse_calculatetotal();"';
				} else {
					$pattern = '#onchange=\"(.*?)\"#is';
					preg_match($pattern,$args['data']['ADDITIONALATTRIBUTES'], $match);
					if ($match && !empty($match[1])) {
						$args['data']['ADDITIONALATTRIBUTES'] = str_replace($match[1], 'rse_calculatetotal();'.$match[1],$args['data']['ADDITIONALATTRIBUTES']);
					}
				}
			}
			
			if ($args['data']['NAME'] == 'RSEProCoupon') {
				if (empty($args['data']['ADDITIONALATTRIBUTES'])) {
					$args['data']['ADDITIONALATTRIBUTES'] = 'onkeyup="rse_calculatetotal();"';
				} else {
					$pattern = '#onkeyup=\"(.*?)\"#is';
					preg_match($pattern,$args['data']['ADDITIONALATTRIBUTES'], $match);
					if ($match && !empty($match[1])) {
						$args['data']['ADDITIONALATTRIBUTES'] = str_replace($match[1], 'rse_calculatetotal();'.$match[1],$args['data']['ADDITIONALATTRIBUTES']);
					}
				}
			}
		}
	}
	
	public function rsfp_bk_onAfterCreateFrontComponentBody($args) {
		if ($args['data']['NAME'] == 'RSEProCoupon') {
			$id = JFactory::getApplication()->input->getInt('id');
			
			$args['out'] .= ' <a href="javascript:void(0)" onclick="rse_verify_coupon('.$id.',$(\'RSEProCoupon\').value)">';
			$args['out'] .= '<img src="'.JURI::root().'components/com_rseventspro/assets/images/coupon.png" alt="'.JText::_('COM_RSEVENTSPRO_COUPON_VERIFY').'" style="vertical-align:middle" />';
			$args['out'] .= '</a>';
		}
		
		if ($args['data']['NAME'] == 'RSEProTickets') {
			$total = '<br /> <span id="grandtotalcontainer" style="display:none;">'.JText::_('COM_RSEVENTSPRO_GLOBAL_TOTAL').': <span id="grandtotal"></span></span>';
			
			$args['out'] = str_replace('id="number"', 'id="number" onchange="rse_calculatetotal();"', $args['out']);
			$args['out'] = str_replace('onkeyup="this.value=this.value.replace(/[^0-9\.\,]/g, \'\');"', 'onkeyup="this.value=this.value.replace(/[^0-9\.\,]/g, \'\');rse_calculatetotal();"', $args['out']);
			$args['out'] = str_replace('<input type="hidden" name="from" id="from" value="" />', '<input type="hidden" name="from" id="from" value="" />'.$total, $args['out']);
		}
	}
	
	protected function placeholders($text,$ide,$name) {
		require_once JPATH_SITE.'/components/com_rseventspro/helpers/rseventspro.php';
		return rseventsproEmails::placeholders($text,$ide, $name);
	}
}