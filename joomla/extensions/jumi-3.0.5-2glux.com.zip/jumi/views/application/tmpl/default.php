<?php
/**
* @version   $Id$
* @package   Jumi
* @copyright (C) 2008 - 2015 Edvard Ananyan
* @license   GNU/GPL v3 http://www.gnu.org/licenses/gpl.html
*/

defined('_JEXEC') or die('Restricted access');