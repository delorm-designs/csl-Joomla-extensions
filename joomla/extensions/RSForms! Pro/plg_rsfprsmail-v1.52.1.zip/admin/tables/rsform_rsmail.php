<?php
/**
* @package RSForm!Pro
* @copyright (C) 2007-2014 www.rsjoomla.com
* @license GPL, http://www.gnu.org/copyleft/gpl.html
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

class TableRSForm_Rsmail extends JTable
{
	public $form_id = null;
	
	public $rsm_list_id 		= '';
	public $rsm_action 			= 1; // 0 - unsubscribe; 1 - subscribe, 2 - let the user decide
	public $rsm_action_field 	= '';
	public $rsm_merge_vars 		= '';
	public $rsm_published 		= 0;
	public $rsm_confirm 		= 0;
	public $rsm_action_type		= 1;
	
	public function __construct(& $db) {
		parent::__construct('#__rsform_rsmail', 'form_id', $db);
	}
}