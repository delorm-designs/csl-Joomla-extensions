DROP TABLE IF EXISTS `#__rsform_rsmail`;
