<?php
/**
* @package RSForm!Pro
* @copyright (C) 2007-2014 www.rsjoomla.com
* @license GPL, http://www.gnu.org/copyleft/gpl.html
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

class plgSystemRSFPRsmail extends JPlugin
{
	public function rsfp_onFormSave($form) {
		$post = JRequest::get('post', JREQUEST_ALLOWRAW);
		$post['form_id'] = $post['formId'];
		
		$row = JTable::getInstance('RSForm_Rsmail', 'Table');
		if (!$row)
			return;
		if (!$row->bind($post)) {
			JError::raiseWarning(500, $row->getError());
			return false;
		}
		
		$row->rsm_merge_vars = serialize($post['rsm_merge_vars']);
		
		$db = JFactory::getDBO();
		$db->setQuery("SELECT form_id FROM #__rsform_rsmail WHERE form_id='".(int) $post['form_id']."'");
		if (!$db->loadResult()) {
			$db->setQuery("INSERT INTO #__rsform_rsmail SET form_id='".(int) $post['form_id']."'");
			$db->execute();
		}
		
		if ($row->store()) {
			return true;
		} else {
			JError::raiseWarning(500, $row->getError());
			return false;
		}
	}
	
	public function rsfp_bk_onFormCopy($args){
		$formId = $args['formId'];
		$newFormId = $args['newFormId'];

		if ($row = JTable::getInstance('RSForm_Rsmail', 'Table') )
		{
			if ($row->load($formId)) {

				if (!$row->bind(array('form_id'=>$newFormId))) {
					JError::raiseWarning(500, $row->getError());
					return false;
				}

				$db 	= JFactory::getDbo();
				$query 	= $db->getQuery(true)
					->select($db->qn('form_id'))
					->from($db->qn('#__rsform_rsmail'))
					->where($db->qn('form_id').'='.$db->q($newFormId));
				if (!$db->setQuery($query)->loadResult()) {
					$query = $db->getQuery(true)
						->insert($db->qn('#__rsform_rsmail'))
						->set($db->qn('form_id').'='.$db->q($newFormId));
					$db->setQuery($query)->execute();
				}

				if ($row->store())
				{
					return true;
				}
				else
				{
					JError::raiseWarning(500, $row->getError());

					return false;
				}
			}
		}
	}
	
	public function rsfp_bk_onAfterShowFormEditTabs() {
		$formId = JFactory::getApplication()->input->getInt('formId');
		
		$lang = JFactory::getLanguage();
		$lang->load('plg_system_rsfprsmail');
		
		if (file_exists(JPATH_SITE.'/components/com_rsmail/helpers/actions.php'))
			require_once JPATH_SITE.'/components/com_rsmail/helpers/actions.php';
		else
			return true;
		
		$row = JTable::getInstance('RSForm_Rsmail', 'Table');
		if (!$row) return;
		$row->load($formId);
		$row->rsm_merge_vars = @unserialize($row->rsm_merge_vars);
		if ($row->rsm_merge_vars === false)
			$row->rsm_merge_vars = array();
		
		// Get a new instance of the RSMail! helper
		$rsmail = new rsmHelper(); 
		
		// Fields
		$fields_array = $this->_getFields($formId);
		$fields = array();
		$fields[] = JHTML::_('select.option', '', JText::_('RSFP_RSM_IGNORE'));
		foreach ($fields_array as $field)
			$fields[] = JHTML::_('select.option', $field, $field);
		
		// Action
		$rsm_action = array(
			JHTML::_('select.option', 1, JText::_('RSFP_RSM_ACTION_SUBSCRIBE')),
			JHTML::_('select.option', 0, JText::_('RSFP_RSM_ACTION_UNSUBSCRIBE')),
			JHTML::_('select.option', 2, JText::_('RSFP_RSM_LET_USER_DECIDE'))
		);
		$lists['rsm_action'] = JHTML::_('select.genericlist', $rsm_action, 'rsm_action', 'onchange="rsfp_changeRsmAction(this);"', 'value', 'text', $row->rsm_action);
		
		// Action Field
		$lists['rsm_action_field'] = JHTML::_('select.genericlist', $fields, 'rsm_action_field', $row->rsm_action != 2 ? 'disabled="disabled"' : '', 'value', 'text', $row->rsm_action_field);
		
		// RSMail! Lists
		$results = $rsmail->getLists();
		$rsm_lists = array(
			JHTML::_('select.option', '0', JText::_('RSFP_PLEASE_SELECT_LIST'))
		);
		if (!empty($results))
			foreach ($results as $result)
				$rsm_lists[] = JHTML::_('select.option', $result->IdList, $result->ListName);
		
		$lists['rsm_list_id'] = JHTML::_('select.genericlist', $rsm_lists, 'rsm_list_id', 'onchange="rsfp_changeRsmList(this)"', 'value', 'text', $row->rsm_list_id);
		
		// Merge Vars
		$merge_vars = array();
		if ($row->rsm_list_id) {
			$rsm_fields = $rsmail->getFields($row->rsm_list_id);
			$merge_vars['rsm_email'] = JText::_('RSFP_RSM_EMAIL');
			if (!empty($rsm_fields)) {
				foreach ($rsm_fields as $field)
					$merge_vars[$field] = $field;
			}
		}
		
		$lists['fields'] = array();
		if (is_array($merge_vars)) {
			foreach ($merge_vars as $merge_var => $title) {
				$lists['fields'][$merge_var] = JHTML::_('select.genericlist', $fields, 'rsm_merge_vars['.$merge_var.']', null, 'value', 'text', isset($row->rsm_merge_vars[$merge_var]) ? $row->rsm_merge_vars[$merge_var] : null);
			}
		}
		
		$rsm_action_type = array(
			JHTML::_('select.option', 1, JText::_('RSFP_RSM_ACTION_TYPE_ERROR')),
			JHTML::_('select.option', 2, JText::_('RSFP_RSM_ACTION_TYPE_UPDATE')),
			JHTML::_('select.option', 3, JText::_('RSFP_RSM_ACTION_TYPE_IGNORE'))
		);
		
		$lists['published'] = RSFormProHelper::renderHTML('select.booleanlist', 'rsm_published', 'class="inputbox"', $row->rsm_published);
		$lists['confirm'] 	= RSFormProHelper::renderHTML('select.booleanlist', 'rsm_confirm', 'class="inputbox"', $row->rsm_confirm);
		$lists['action_type']	= JHTML::_('select.genericlist', $rsm_action_type, 'rsm_action_type', '', 'value', 'text', $row->rsm_action_type);
		
		echo '<div id="rsmaildiv">';
			include JPATH_ADMINISTRATOR.'/components/com_rsform/helpers/rsmail.php';
		echo '</div>';
	}
	
	public function rsfp_bk_onAfterShowFormEditTabsTab() {
		$lang = JFactory::getLanguage();
		$lang->load('plg_system_rsfprsmail');
		
		echo '<li><a href="javascript: void(0);" id="rsmail"><span class="rsficon rsficon-envelope-o"></span><span class="inner-text">'.JText::_('RSFP_RSMAIL_INTEGRATION').'</span></a></li>';
	}
	
	protected function _getSubmission($SubmissionId) {
		static $cache = array();
		
		if (!isset($cache[$SubmissionId])) {
			$db 	= JFactory::getDbo();
			$query 	= $db->getQuery(true);
			
			$query->select('*')
				  ->from($db->qn('#__rsform_submissions'))
				  ->where($db->qn('SubmissionId').'='.$db->q($SubmissionId));
			$cache[$SubmissionId] = $db->setQuery($query)->loadObject();
		}
		
		return $cache[$SubmissionId];
	}
	
	protected function _getRow($formId) {
		static $cache = array();
		
		if (!isset($cache[$formId])) {
			$db 	= JFactory::getDbo();
			$query 	= $db->getQuery(true);
			
			$query->select('*')
				  ->from($db->qn('#__rsform_rsmail'))
				  ->where($db->qn('form_id').'='.$db->q($formId))
				  ->where($db->qn('rsm_published').'='.$db->q(1));
			$cache[$formId] = $db->setQuery($query)->loadObject();
			
			$row =& $cache[$formId];
			if ($row) {
				$row->rsm_merge_vars = @unserialize($row->rsm_merge_vars);
				if ($row->rsm_merge_vars === false)
					$row->rsm_merge_vars = array();
			}
		}
		
		return $cache[$formId];
	}
	
	protected function _transformData($SubmissionId) {
		$db 		= JFactory::getDbo();
		$query		= $db->getQuery(true);
		$submission = $this->_getSubmission($SubmissionId);
		$formId		= $submission->FormId;
		
		$query->select($db->qn('FieldName'))
			  ->select($db->qn('FieldValue'))
			  ->from($db->qn('#__rsform_submission_values'))
			  ->where($db->qn('SubmissionId').'='.$db->q($SubmissionId));
		$submission->values = $db->setQuery($query)->loadObjectList('FieldName');
		
		$db->setQuery("SELECT p.PropertyValue AS name, c.ComponentId, c.ComponentTypeId, ct.ComponentTypeName, c.Order FROM #__rsform_properties p LEFT JOIN #__rsform_components c ON (c.ComponentId=p.ComponentId) LEFT JOIN #__rsform_component_types ct ON (ct.ComponentTypeId=c.ComponentTypeId) WHERE c.FormId='".$formId."' AND p.PropertyName='NAME' AND c.Published='1' ORDER BY c.Order");
		$components = $db->loadObjectList();
		
		foreach ($components as $component) {
			if (isset($submission->values[$component->name])) {
				$data[$component->name] = $submission->values[$component->name]->FieldValue;
				if (in_array($component->ComponentTypeId, array(3, 4))) {
					$data[$component->name] = explode("\n", $data[$component->name]);
				}
			} else {
				$data[$component->name] = '';
			}
		}
		
		return $data;
	}
	
	protected function _getAction($row, $form) {
		$subscribe = null;
		if ($row->rsm_action == 1)
			$subscribe = true;
		elseif ($row->rsm_action == 0)
			$subscribe = false;
		elseif ($row->rsm_action == 2 && isset($form[$row->rsm_action_field])) {
			if (is_array($form[$row->rsm_action_field]))
				foreach ($form[$row->rsm_action_field] as $i => $value)
				{
					$value = strtolower(trim($value));
					if ($value == 'subscribe')
					{
						$subscribe = true;
						break;
					}
					elseif ($value == 'unsubscribe')
					{
						$subscribe = false;
						break;
					}
				}
			else
			{
				$form[$row->rsm_action_field] = strtolower(trim($form[$row->rsm_action_field]));
				if ($form[$row->rsm_action_field] == 'subscribe')
					$subscribe = true;
				elseif ($form[$row->rsm_action_field] == 'unsubscribe')
					$subscribe = false;
			}
		}
		
		return $subscribe;
	}
	
	protected function _doAction($row, $SubmissionId, $form = null) {
		if (file_exists(JPATH_SITE.'/components/com_rsmail/helpers/actions.php')) {
			require_once JPATH_SITE.'/components/com_rsmail/helpers/actions.php';
			
			// Get a new instance of the RSMail! helper
			$rsmail = new rsmHelper(); 
			
			if (isset($row->rsm_merge_vars['rsm_email'])) {
				if (!$form) {
					$form = $this->_transformData($SubmissionId);
				}
				
				$email_address = @$form[$row->rsm_merge_vars['rsm_email']];
				
				$merge_vars = array();
				$email = $email_address;
				foreach ($row->rsm_merge_vars as $tag => $field) {
					if (empty($tag)) continue;
					if ($tag == 'rsm_email') continue;
					
					if (!isset($form[$field]))
						$form[$field] = '';
					
					if (is_array($form[$field])) {
						array_walk($form[$field], array($this, '_escapeCommas'));
						$form[$field] = implode(',', $form[$field]);
					}
					
					$merge_vars[$tag] = $form[$field];
				}
				
				$list_id = $row->rsm_list_id;
				
				// Subscribe action - Subscribe, Unsubscribe or Let the user choose
				$subscribe = $this->_getAction($row, $form);
				
				// Prepare list
				$list = $rsmail->setList($row->rsm_list_id, $merge_vars);
				
				/* $subscribe = true - subscribe user
				$subscribe = false - unsubscribe user
				$subscribe = null - do nothing */
				if ($subscribe === true) {
					if ($rsmail->isSubscribed($email, $row->rsm_list_id) && $row->rsm_action_type == 3) {
						return;
					}
					
					$state = $rsmail->getState();
					
					if ($row->rsm_action_type == 2) {
						$db = JFactory::getDbo();
						$db->setQuery('SELECT '.$db->qn('published').' FROM '.$db->qn('#__rsmail_subscribers').' WHERE '.$db->qn('SubscriberEmail').' = '.$db->q($email).' AND '.$db->qn('IdList').' = '.$db->q($row->rsm_list_id));
						$user_state = $db->loadResult();
						
						if (!is_null($user_state)) {
							$state = $user_state;
						}
						
						$confirmation = rsmailHelper::getMessage('confirmation');
						if (!$confirmation->enable) {
							$state = 1;
						}
					}
					
					// Subscribe user
					$idsubscriber = $rsmail->subscribe($email, $list, $state, null, true);
					
					if ($idsubscriber) {
						// The user must confirm his subscription
						if (!$state) {
							$hash = md5($row->rsm_list_id.$idsubscriber.$email);
							$rsmail->confirmation($row->rsm_list_id, $email, $hash);
						}
						
						//Send notifications
						if ($row->rsm_action_type != 2) {
							$rsmail->notifications($row->rsm_list_id, $email, $merge_vars);
						}
					}
				} elseif ($subscribe === false) {
					$rsmail->unsubscribeLink($email, $row->rsm_list_id);
				}
			}
		}
	}
	
	public function rsfp_f_onSubmissionConfirmation($args) {
		$SubmissionId = $args['SubmissionId'];
		if ($submission = $this->_getSubmission($SubmissionId)) {
			$formId = $submission->FormId;
			if ($row = $this->_getRow($formId)) {
				if ($row->rsm_list_id && $row->rsm_confirm) {
					$this->_doAction($row, $SubmissionId);
				}
			}
		}
	}
	
	public function rsfp_f_onAfterFormProcess($args) {
		$formId 		= (int) $args['formId'];
		$SubmissionId 	= (int) $args['SubmissionId'];
		
		JFactory::getLanguage()->load('com_rsmail', JPATH_SITE);
		
		if ($row = $this->_getRow($formId))
		{
			// No list selected.
			if (!$row->rsm_list_id) return;
			// Confirmation by email enabled.
			if ($row->rsm_confirm) return;
			
			$form = JRequest::getVar('form');			
			$this->_doAction($row, $SubmissionId, $form);
		}
	}
	
	/**
	 *	Form Validation
	 */
	public function rsfp_f_onBeforeFormValidation($args) {
		$db 	= JFactory::getDBO();
		$lang 	= JFactory::getLanguage();
		$formId = (int) $args['formId'];
		$form	= $args['post'];
		$lang->load('com_rsmail',JPATH_SITE);
		
		if ($row = $this->_getRow($formId))
		{
			if (file_exists(JPATH_SITE.'/components/com_rsmail/helpers/actions.php')) {
				require_once JPATH_SITE.'/components/com_rsmail/helpers/actions.php';
				
				$email_field = $row->rsm_merge_vars['rsm_email'];
				
				if (!isset($email_field)) {
					$args['invalid'][] = $this->_getComponentId($email_field, $formId);
				}
				
				// Get a new instance of the RSMail! helper
				$rsmail = new rsmHelper();
				
				$email_address = @$form[$row->rsm_merge_vars['rsm_email']];
				
				// Subscribe action - Subscribe, Unsubscribe or Let the user choose
				$subscribe = $this->_getAction($row, $form);
				
				if ($subscribe && $row->rsm_action_type == 1) {
					if ($rsmail->isSubscribed($email_address, $row->rsm_list_id)) {
						JError::raiseWarning(500, JText::_('RSM_ALREADY_SUBSCRIBED'));
						$args['invalid'][] = $this->_getComponentId($email_field, $formId);
					}
				}
			}
		}
	}
	
	public function rsfp_bk_onSwitchTasks() {
		$lang = JFactory::getLanguage();
		$lang->load('plg_system_rsfprsmail');
		
		$plugin_task = JRequest::getVar('plugin_task');
		
		if ($plugin_task == 'rsm_get_merge_vars')
		{
			if (file_exists(JPATH_SITE.'/components/com_rsmail/helpers/actions.php'))
				require_once JPATH_SITE.'/components/com_rsmail/helpers/actions.php';
			else
				return true;
			
			$list = JRequest::getVar('list_id');
			
			if (!empty($list)) {
				// Get a new instance of the RSMail! helper
				$rsmail = new rsmHelper();
				// Get list fields
				$results = $rsmail->getFields($list);
			
				echo 'rsm_email_'.JText::_('RSFP_RSM_EMAIL');
				echo is_array($results) && !empty($results) ? "\n".implode("\n",$results) : '';
			}
			jexit();
		}
	}
	
	protected function _getFields($formId) {
		$db = JFactory::getDBO();
		
		$db->setQuery("SELECT p.PropertyValue FROM #__rsform_components c LEFT JOIN #__rsform_properties p ON (c.ComponentId=p.ComponentId) WHERE c.FormId='".(int) $formId."' AND p.PropertyName='NAME' ORDER BY c.Order");
		return $db->loadColumn();
	}
	
	protected function _escapeCommas(&$item) {
		$item = str_replace(',', '\,', $item);
	}
	
	protected function _getComponentId($name, $formId) {		
		if (method_exists('RSFormProHelper', 'getComponentId'))
			return RSFormProHelper::getComponentId($name, $formId);
		
		static $cache;
		if (!is_array($cache))
			$cache = array();
			
		if (empty($formId)) {
			$formId = JFactory::getApplication()->input->getInt('formId');
			if (empty($formId)) {
				$post   = JFactory::getApplication()->input->get('form',array(),'array');
				$formId = (int) @$post['formId'];
			}
		}
		
		if (!isset($cache[$formId][$name]))
			$cache[$formId][$name] = RSFormProHelper::componentNameExists($name, $formId);
		
		return $cache[$formId][$name];
	}
	
	public function rsfp_onFormDelete($formId) {
		$db 	= JFactory::getDbo();
		$query 	= $db->getQuery(true);
		$query->delete('#__rsform_rsmail')
			  ->where($db->qn('form_id').'='.$db->q($formId));
		$db->setQuery($query)->execute();
	}
	
	public function rsfp_onFormBackup($form, $xml, $fields) {
		$db 	= JFactory::getDbo();
		$query 	= $db->getQuery(true);
		$query->select('*')
			  ->from($db->qn('#__rsform_rsmail'))
			  ->where($db->qn('form_id').'='.$db->q($form->FormId));
		$db->setQuery($query);
		if ($rsmail = $db->loadObject()) {
			// No need for a form_id
			unset($rsmail->form_id);
			
			$xml->add('rsmail');
			foreach ($rsmail as $property => $value) {
				$xml->add($property, $value);
			}
			$xml->add('/rsmail');
		}
	}
	
	public function rsfp_onFormRestore($form, $xml, $fields) {
		if (isset($xml->rsmail)) {
			$data = array(
				'form_id' => $form->FormId
			);
			
			foreach ($xml->rsmail->children() as $property => $value) {
				$data[$property] = (string) $value;
			}
			
			$row = JTable::getInstance('RSForm_Rsmail', 'Table');
			
			if (!$row->load($form->FormId)) {
				$db = JFactory::getDBO();
				$query = $db->getQuery(true);
				$query	->insert('#__rsform_rsmail')
						->set(array(
								$db->qn('form_id') .'='. $db->q($form->FormId),
						));
				$db->setQuery($query)->execute();
			}
			
			$row->save($data);
		}
	}
	
	public function rsfp_bk_onFormRestoreTruncate() {
		JFactory::getDbo()->truncateTable('#__rsform_rsmail');
	}
}