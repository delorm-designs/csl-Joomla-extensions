<?php

/**
 * Exception class for OAuth failures.
 */
class OAuthException extends Exception
{
	// pass
}

