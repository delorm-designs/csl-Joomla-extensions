DROP TABLE IF EXISTS `#__rsform_eway`;
DELETE FROM #__rsform_component_types WHERE ComponentTypeId = 501;
DELETE FROM #__rsform_component_type_fields WHERE ComponentTypeId = 501;

DELETE FROM #__rsform_config WHERE SettingName = 'eway.username';
DELETE FROM #__rsform_config WHERE SettingName = 'eway.password';
DELETE FROM #__rsform_config WHERE SettingName = 'eway.test';
