INSERT IGNORE INTO `#__rsform_component_types` (`ComponentTypeId`, `ComponentTypeName`) VALUES (501, 'eway');

DELETE FROM #__rsform_component_type_fields WHERE ComponentTypeId = 501;
INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES
(501, 'NAME', 'textbox', '', 0),
(501, 'LABEL', 'textbox', '', 1),
(501, 'COMPONENTTYPE', 'hidden', '501', 2),
(501, 'LAYOUTHIDDEN', 'hiddenparam', 'YES', 7);

CREATE TABLE IF NOT EXISTS `#__rsform_eway` (
  `form_id` int(11) NOT NULL,
  `merge_vars` text NOT NULL,
  PRIMARY KEY (`form_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT IGNORE INTO `#__rsform_config` (`SettingName`, `SettingValue`) VALUES
('eway.username', ''),
('eway.password', ''),
('eway.test', '0');