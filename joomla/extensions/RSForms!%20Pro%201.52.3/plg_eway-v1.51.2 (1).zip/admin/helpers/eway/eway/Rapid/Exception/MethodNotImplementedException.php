<?php

namespace Eway\Rapid\Exception;

use RuntimeException;

/**
 * Class MethodNotImplementedException.
 */
class MethodNotImplementedException extends RuntimeException
{
}
