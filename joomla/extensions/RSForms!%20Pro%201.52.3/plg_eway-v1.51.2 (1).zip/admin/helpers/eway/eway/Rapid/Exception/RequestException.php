<?php

namespace Eway\Rapid\Exception;

use RuntimeException;

/**
 * Class RequestException.
 */
class RequestException extends RuntimeException
{
}
