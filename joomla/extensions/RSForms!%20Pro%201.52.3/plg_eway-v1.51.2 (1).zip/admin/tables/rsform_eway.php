<?php
/**
* @package RSform!Pro
* @copyright (C) 2015 www.rsjoomla.com
* @license GPL, http://www.gnu.org/copyleft/gpl.html
*/

defined('_JEXEC') or die('Restricted access');

class TableRSForm_Eway extends JTable
{
	public $form_id = null;
	public $merge_vars = '';
	
	public function __construct(& $db) {
		parent::__construct('#__rsform_eway', 'form_id', $db);
	}
}