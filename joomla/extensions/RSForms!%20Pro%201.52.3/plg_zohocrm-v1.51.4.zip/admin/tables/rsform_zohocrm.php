<?php
/**
* @package RSform!Pro
* @copyright (C) 2015 www.rsjoomla.com
* @license GPL, http://www.gnu.org/copyleft/gpl.html
*/

defined('_JEXEC') or die('Restricted access');

class TableRSForm_ZohoCrm extends JTable
{
	public $form_id 			= null;	
	public $zh_wf_trigger 		= 1;
	public $zh_duplicate_check  = 1;
	public $zh_is_approval 		= 0;
	public $zh_format 			= 1;
	public $zh_merge_vars 		= '';
	public $zh_debug 			= 0;
	public $zh_published 		= 0;
	public $zh_track_ga			= 0;
		
	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 */
	public function __construct(& $db) {
		parent::__construct('#__rsform_zohocrm', 'form_id', $db);
	}
}