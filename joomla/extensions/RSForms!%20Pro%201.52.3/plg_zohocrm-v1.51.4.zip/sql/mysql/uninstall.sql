DROP TABLE IF EXISTS `#__rsform_zohocrm`;

DELETE FROM #__rsform_config WHERE SettingName = 'zohocrm.token';
