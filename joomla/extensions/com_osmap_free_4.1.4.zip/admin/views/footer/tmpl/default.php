<?php
/**
 * @package   AllediaFreeDefaultFiles
 * @copyright 2016 Alledia.com, All rights reserved.
 * @author    Alledia <support@alledia.com>
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU/GPL
 */

defined('_JEXEC') or die('Restricted access');
?>
<div class="row-fluid">
    <div id="footer" class="span12">
        <div>
            <a href="https://www.alledia.com">
                <img src="../media/<?php echo $this->option; ?>/images/alledia_logo_150x43.png" />
            </a>
        </div>
        <br />
        <div>
            Powered by&nbsp;
            <a href="https://www.alledia.com">Alledia</a>
        </div>
    </div>
</div>
