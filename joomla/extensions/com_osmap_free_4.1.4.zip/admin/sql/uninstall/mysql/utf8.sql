SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `#__osmap_sitemaps`;
DROP TABLE IF EXISTS `#__osmap_sitemap_menus`;
DROP TABLE IF EXISTS `#__osmap_items_settings`;

SET foreign_key_checks = 1;
